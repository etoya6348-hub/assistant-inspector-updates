# -*- coding: utf-8 -*-
"""Nutqni matnga aylantirish (STT).

Ikki ish rejimi:
  * OFLAYN  — internet talab qilinmaydi. Model kompyuterda ishlaydi:
        - Whisper (faster-whisper / CTranslate2). Tavsiya etiladi: o‘zbek tiliga
          maxsus o‘rgatilgan "rubaistt_v2_medium" (WER ≈ 17%) yoki "large-v3".
        - Vosk (yengil o‘zbekcha model, kuchsiz kompyuterlar uchun).
  * ONLAYN  — internet orqali:
        - Google Speech (bepul, kalit talab qilinmaydi, uz-UZ)
        - OpenAI (gpt-4o-transcribe / whisper-1, API kalit talab qilinadi)
  * AVTO    — internet bo‘lsa onlayn, bo‘lmasa (yoki xato bo‘lsa) oflayn.
"""
import io
import re
import socket
import wave
from pathlib import Path

import numpy as np

from .audio import SR, split_on_silence
from .config import models_dir
from .translit import convert

_MODEL_CACHE = {}

UZ_PROMPT = ("Assalomu alaykum. Men 2026-yil oktabr oyida Namangan shahrida boʻlib oʻtgan "
             "voqea haqida tushuntirish beraman. Savol: Javob:")


class STTError(Exception):
    pass


def is_online(timeout=1.5) -> bool:
    for host in (("8.8.8.8", 53), ("1.1.1.1", 53)):
        try:
            socket.create_connection(host, timeout=timeout).close()
            return True
        except OSError:
            continue
    return False


def _pcm16(audio: np.ndarray) -> bytes:
    return (np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes()


def _wav_bytes(audio: np.ndarray) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(_pcm16(audio))
    return buf.getvalue()


# ------------------------------------------------------------------ #
#                              OFLAYN                                #
# ------------------------------------------------------------------ #
def _resolve_model(name: str) -> str:
    p = Path(name)
    if p.is_dir():
        return str(p)
    local = models_dir() / name
    if local.is_dir():
        return str(local)
    return name  # faster-whisper o‘zi yuklab oladi (faqat internet bo‘lsa)


def transcribe_whisper(audio, settings, progress=None):
    try:
        from faster_whisper import WhisperModel
    except ImportError as e:
        raise STTError("faster-whisper oʻrnatilmagan: pip install faster-whisper") from e
    name = settings.get("whisper_model") or "large-v3"
    known = {"tiny", "base", "small", "medium", "large-v1", "large-v2", "large-v3", "large",
             "large-v3-turbo", "turbo", "distil-large-v3"}
    if name not in known and not Path(_resolve_model(name)).is_dir():
        raise STTError(f"Oflayn Whisper modeli hali yuklab olinmagan: {name}\n"
                       f"download_models.bat orqali yuklab oling (papka: {models_dir()}).")
    device = settings.get("whisper_device", "auto")
    if device == "auto":
        try:
            import ctranslate2
            device = "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
        except Exception:
            device = "cpu"
    compute = settings.get("whisper_compute", "auto")
    if compute == "auto":
        compute = "float16" if device == "cuda" else "float32"
    key = (name, device, compute)
    model = _MODEL_CACHE.get(key)
    if model is None:
        if progress:
            progress(-1, "model")
        path = _resolve_model(name)
        local = Path(path).is_dir()
        try:
            model = WhisperModel(path, device=device, compute_type=compute,
                                 download_root=str(models_dir()),
                                 local_files_only=(not local and not is_online()))
        except Exception as e:  # noqa
            raise STTError(f"Whisper modeli yuklanmadi: {name}\n{e}\n\n"
                           f"Modelni oldindan yuklab oling: download_models.bat\n"
                           f"(papka: {models_dir()})") from e
        _MODEL_CACHE.clear()
        _MODEL_CACHE[key] = model
    total = max(1e-6, len(audio) / SR)
    segments, _info = model.transcribe(
        audio, language="uz", task="transcribe", beam_size=5, best_of=5,
        vad_filter=True, vad_parameters={"min_silence_duration_ms": 500},
        condition_on_previous_text=False, initial_prompt=UZ_PROMPT, temperature=0.0)
    texts = []
    for seg in segments:
        texts.append(seg.text.strip())
        if progress:
            progress(min(99, int(seg.end / total * 100)), "")
    return " ".join(t for t in texts if t)


def transcribe_vosk(audio, settings, progress=None):
    try:
        from vosk import KaldiRecognizer, Model, SetLogLevel
    except ImportError as e:
        raise STTError("vosk oʻrnatilmagan: pip install vosk") from e
    import json
    SetLogLevel(-1)
    name = settings.get("vosk_model") or "vosk-model-small-uz-0.22"
    path = _resolve_model(name)
    if not Path(path).is_dir():
        raise STTError(f"Vosk modeli topilmadi: {models_dir() / name}")
    model = _MODEL_CACHE.get(("vosk", path))
    if model is None:
        model = Model(path)
        _MODEL_CACHE[("vosk", path)] = model
    rec = KaldiRecognizer(model, SR)
    pcm = _pcm16(audio)
    step = SR * 2 * 2  # 2 soniya
    parts = []
    for i in range(0, len(pcm), step):
        if rec.AcceptWaveform(pcm[i:i + step]):
            parts.append(json.loads(rec.Result()).get("text", ""))
        if progress:
            progress(int(i / max(1, len(pcm)) * 100), "")
    parts.append(json.loads(rec.FinalResult()).get("text", ""))
    # Vosk har bir gapni alohida qaytaradi -> gaplar sifatida birlashtiramiz
    sents = [p.strip() for p in parts if p.strip()]
    return ". ".join(s[:1].upper() + s[1:] for s in sents)


# ------------------------------------------------------------------ #
#                              ONLAYN                                #
# ------------------------------------------------------------------ #
def transcribe_google(audio, settings, progress=None):
    try:
        import speech_recognition as sr
    except ImportError as e:
        raise STTError("SpeechRecognition oʻrnatilmagan: pip install SpeechRecognition") from e
    r = sr.Recognizer()
    chunks = split_on_silence(audio, max_sec=45)
    out = []
    for i, ch in enumerate(chunks):
        if len(ch) < SR * 0.4:
            continue
        data = sr.AudioData(_pcm16(ch), SR, 2)
        try:
            out.append(r.recognize_google(data, language="uz-UZ"))
        except sr.UnknownValueError:
            pass
        except sr.RequestError as e:
            raise STTError(f"Google xizmati bilan aloqa yoʻq: {e}") from e
        if progress:
            progress(int((i + 1) / len(chunks) * 100), "")
    return ". ".join(s.strip() for s in out if s.strip())


def transcribe_openai(audio, settings, progress=None):
    import requests
    key = (settings.get("openai_key") or "").strip()
    if not key:
        raise STTError("OpenAI API kaliti kiritilmagan (Sozlamalar → Onlayn).")
    model = settings.get("openai_model") or "gpt-4o-transcribe"
    chunks = split_on_silence(audio, max_sec=600)
    out = []
    for i, ch in enumerate(chunks):
        files = {"file": ("audio.wav", _wav_bytes(ch), "audio/wav")}
        data = {"model": model, "language": "uz",
                "prompt": "Oʻzbek tilida, lotin alifbosida yozing. " + UZ_PROMPT}
        try:
            resp = requests.post("https://api.openai.com/v1/audio/transcriptions",
                                 headers={"Authorization": f"Bearer {key}"},
                                 files=files, data=data, timeout=600)
        except requests.RequestException as e:
            raise STTError(f"OpenAI bilan aloqa yoʻq: {e}") from e
        if resp.status_code != 200:
            raise STTError(f"OpenAI xatosi {resp.status_code}: {resp.text[:300]}")
        out.append(resp.json().get("text", ""))
        if progress:
            progress(int((i + 1) / len(chunks) * 100), "")
    return " ".join(out)


# ------------------------------------------------------------------ #
def postprocess(text: str, script: str) -> str:
    text = re.sub(r"\s+", " ", (text or "")).strip()
    if not text:
        return ""
    text = convert(text, script)
    text = re.sub(r"\s+([,.!?;:])", r"\1", text)
    # Gap boshini katta harf bilan
    text = re.sub(r"(^|[.!?]\s+)(\w)", lambda m: m.group(1) + m.group(2).upper(), text)
    if text[-1] not in ".!?…":
        text += "."
    return text


def transcribe(audio: np.ndarray, settings, script="latn", progress=None):
    """Asosiy funksiya. Qaytaradi: (matn, ishlatilgan_rejim_nomi)."""
    if audio is None or len(audio) < SR * 0.3:
        raise STTError("Audio juda qisqa yoki boʻsh.")
    mode = settings.get("stt_mode", "auto")
    online_ok = mode == "online" or (mode == "auto" and is_online())

    def offline():
        if settings.get("offline_engine") == "vosk":
            return transcribe_vosk(audio, settings, progress), "offline:vosk"
        return transcribe_whisper(audio, settings, progress), "offline:whisper"

    online_error = None
    if online_ok:
        use_openai = (settings.get("online_engine") == "openai"
                      and (settings.get("openai_key") or "").strip())
        try:
            if use_openai:
                raw, used = transcribe_openai(audio, settings, progress), "online:openai"
            else:
                # OpenAI kaliti kiritilmagan bo‘lsa — bepul Google xizmati ishlatiladi
                raw, used = transcribe_google(audio, settings, progress), "online:google"
            return postprocess(raw, script), used
        except STTError as e:
            if mode == "online":
                raise
            online_error = str(e)
    try:
        raw, used = offline()
    except STTError as e:
        if online_error:
            raise STTError(f"Onlayn xizmat ishlamadi:\n{online_error}\n\n"
                           f"Oflayn rejim ham ishlamadi:\n{e}") from e
        if mode == "auto" and not online_ok:
            raise STTError("Internet aloqasi yoʻq va oflayn model hali yuklab olinmagan.\n"
                           "Internetni ulang yoki download_models.bat orqali oflayn modelni yuklab oling.") from e
        raise
    return postprocess(raw, script), used
