# -*- coding: utf-8 -*-
"""Admin paneli, PIN qulf va obuna oynalari."""
import threading

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QApplication, QCheckBox, QDialog, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QTabWidget,
                               QVBoxLayout, QWidget)

from . import licensing, security
from .config import APP_VERSION


def _pw_edit(ph=""):
    e = QLineEdit()
    e.setEchoMode(QLineEdit.Password)
    e.setPlaceholderText(ph)
    return e


class PasswordDialog(QDialog):
    """Parol so‘rash. create=True bo‘lsa yangi parol o‘rnatadi."""

    def __init__(self, parent, t, title, text, create=False, can_exit=False):
        super().__init__(parent)
        self.t = t
        self.create = create
        self.value = None
        self.setWindowTitle(title)
        self.setMinimumWidth(380)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(10)
        lbl = QLabel(text)
        lbl.setWordWrap(True)
        lay.addWidget(lbl)
        self.e1 = _pw_edit(t("new_password") if create else t("password"))
        lay.addWidget(self.e1)
        self.e2 = None
        if create:
            self.e2 = _pw_edit(t("repeat_password"))
            lay.addWidget(self.e2)
        self.err = QLabel()
        self.err.setStyleSheet("color:#DC2626")
        lay.addWidget(self.err)
        row = QHBoxLayout()
        if can_exit:
            b_exit = QPushButton(t("exit"))
            b_exit.clicked.connect(self.reject)
            row.addWidget(b_exit)
        row.addStretch(1)
        ok = QPushButton(t("unlock") if not create else t("save"))
        ok.setObjectName("primary")
        ok.setDefault(True)
        ok.clicked.connect(self._ok)
        row.addWidget(ok)
        lay.addLayout(row)
        self.e1.setFocus()

    def _ok(self):
        v = self.e1.text()
        if self.create:
            if len(v) < 6 or v != self.e2.text():
                self.err.setText(self.t("pw_mismatch"))
                return
        self.value = v
        self.accept()


def ask_password(parent, t, stored_hash, title, text, can_exit=False, attempts=5):
    for _ in range(attempts):
        d = PasswordDialog(parent, t, title, text, can_exit=can_exit)
        if not d.exec():
            return False
        if security.verify_password(d.value, stored_hash):
            return True
        QMessageBox.warning(parent, title, t("wrong_password"))
    security.audit("PAROL: ko‘p marta noto‘g‘ri kiritildi")
    return False


class LicenseDialog(QDialog):
    def __init__(self, parent, t, settings):
        super().__init__(parent)
        self.t, self.settings = t, settings
        self.setWindowTitle(t("license_title"))
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(10)
        info = QLabel(t("license_need"))
        info.setWordWrap(True)
        lay.addWidget(info)
        lay.addWidget(_device_row(t))
        lay.addWidget(QLabel(t("license_key")))
        self.key = QPlainTextEdit()
        self.key.setFixedHeight(80)
        self.key.setPlainText(security.decrypt_text(settings["security"].get("license_key", "")))
        lay.addWidget(self.key)
        self.status = QLabel()
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        row = QHBoxLayout()
        b_exit = QPushButton(t("exit"))
        b_exit.clicked.connect(self.reject)
        b_ok = QPushButton(t("activate"))
        b_ok.setObjectName("primary")
        b_ok.clicked.connect(self._activate)
        row.addWidget(b_exit)
        row.addStretch(1)
        row.addWidget(b_ok)
        lay.addLayout(row)

    def _activate(self):
        key = self.key.toPlainText().strip()
        ok, msg = licensing.check_license(key, security.device_id())
        self.status.setText(msg)
        self.status.setStyleSheet("color:#16A34A" if ok else "color:#DC2626")
        if ok:
            sec = dict(self.settings["security"])
            sec["license_key"] = security.encrypt_text(key)
            self.settings["security"] = sec
            security.audit("OBUNA: kalit faollashtirildi")
            QTimer.singleShot(700, self.accept)


def _device_row(t):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    did = security.device_id()
    lbl = QLabel(f"{t('device_id')}: <b>{did}</b>")
    lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
    b = QPushButton(t("copy"))
    b.clicked.connect(lambda: QApplication.clipboard().setText(did))
    h.addWidget(lbl)
    h.addStretch(1)
    h.addWidget(b)
    return w


class AdminPanel(QDialog):
    def __init__(self, win):
        super().__init__(win)
        self.win = win
        t = self.t = win.t
        S = self.S = win.settings
        self.setWindowTitle(t("admin_panel"))
        self.setMinimumSize(620, 520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        tabs = QTabWidget()
        lay.addWidget(tabs, 1)
        sec = S["security"]

        # --- Xavfsizlik ---
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)
        b_pw = QPushButton("🔑 " + t("change_admin_pw"))
        b_pw.clicked.connect(self._change_admin_pw)
        v.addWidget(b_pw)
        v.addWidget(QLabel(t("app_pin")))
        r = QHBoxLayout()
        b_pin = QPushButton(t("set_pin"))
        b_pin.clicked.connect(self._set_pin)
        b_cpin = QPushButton(t("clear_pin"))
        b_cpin.clicked.connect(self._clear_pin)
        r.addWidget(b_pin)
        r.addWidget(b_cpin)
        r.addStretch(1)
        v.addLayout(r)
        r = QHBoxLayout()
        r.addWidget(QLabel(t("autolock")))
        self.sp_lock = QSpinBox()
        self.sp_lock.setRange(0, 240)
        self.sp_lock.setValue(int(sec.get("autolock_min", 0)))
        r.addWidget(self.sp_lock)
        v.addLayout(r)
        self.cb_off = QCheckBox(t("offline_only"))
        self.cb_off.setChecked(sec.get("offline_only", False))
        self.cb_lock = QCheckBox(t("lock_settings"))
        self.cb_lock.setChecked(sec.get("settings_locked", False))
        v.addWidget(self.cb_off)
        v.addWidget(self.cb_lock)
        v.addStretch(1)
        tabs.addTab(w, t("sec_tab"))

        # --- Yangilanish ---
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(QLabel(f"Versiya: {APP_VERSION}"))
        v.addWidget(QLabel(t("update_url")))
        self.ed_url = QLineEdit(sec.get("update_url", ""))
        self.ed_url.setPlaceholderText("https://…/ai-update")
        v.addWidget(self.ed_url)
        self.cb_auto = QCheckBox(t("auto_update"))
        self.cb_auto.setChecked(sec.get("auto_update", True))
        v.addWidget(self.cb_auto)
        b_chk = QPushButton("⟳ " + t("check_update"))
        b_chk.clicked.connect(self._check_update)
        v.addWidget(b_chk)
        self.upd_status = QLabel()
        self.upd_status.setWordWrap(True)
        v.addWidget(self.upd_status)
        if not licensing.is_configured():
            n = QLabel(t("keys_missing"))
            n.setObjectName("lockNote")
            n.setWordWrap(True)
            v.addWidget(n)
        v.addStretch(1)
        tabs.addTab(w, t("upd_tab"))

        # --- Obuna ---
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(_device_row(t))
        self.cb_lic = QCheckBox(t("require_license"))
        self.cb_lic.setChecked(sec.get("require_license", False))
        v.addWidget(self.cb_lic)
        ok, msg = licensing.check_license(security.decrypt_text(sec.get("license_key", "")),
                                          security.device_id())
        st = QLabel(msg)
        st.setWordWrap(True)
        v.addWidget(st)
        b = QPushButton(t("license_key") + "…")
        b.clicked.connect(lambda: LicenseDialog(self, t, S).exec())
        v.addWidget(b)
        if not licensing.is_configured():
            n = QLabel(t("keys_missing"))
            n.setObjectName("lockNote")
            n.setWordWrap(True)
            v.addWidget(n)
        v.addStretch(1)
        tabs.addTab(w, t("lic_tab"))

        # --- Jurnal ---
        w = QWidget()
        v = QVBoxLayout(w)
        log = QPlainTextEdit(security.read_audit())
        log.setReadOnly(True)
        v.addWidget(log)
        tabs.addTab(w, t("log_tab"))

        row = QHBoxLayout()
        b_out = QPushButton(t("admin_logout"))
        b_out.clicked.connect(self._logout)
        row.addWidget(b_out)
        row.addStretch(1)
        b_save = QPushButton(t("save"))
        b_save.setObjectName("primary")
        b_save.clicked.connect(self._save)
        row.addWidget(b_save)
        lay.addLayout(row)

    def _sec(self):
        return dict(self.S["security"])

    def _change_admin_pw(self):
        d = PasswordDialog(self, self.t, self.t("change_admin_pw"), self.t("new_password"), create=True)
        if d.exec():
            s = self._sec()
            s["admin_hash"] = security.hash_password(d.value)
            self.S["security"] = s
            security.audit("ADMIN: parol o‘zgartirildi")
            QMessageBox.information(self, self.t("admin_panel"), self.t("pw_changed"))

    def _set_pin(self):
        d = PasswordDialog(self, self.t, self.t("set_pin"), self.t("app_pin"), create=True)
        if d.exec():
            s = self._sec()
            s["pin_hash"] = security.hash_password(d.value)
            self.S["security"] = s
            security.audit("ADMIN: PIN o‘rnatildi")
            QMessageBox.information(self, self.t("admin_panel"), self.t("pw_changed"))

    def _clear_pin(self):
        s = self._sec()
        s["pin_hash"] = ""
        self.S["security"] = s
        security.audit("ADMIN: PIN o‘chirildi")

    def _check_update(self):
        url = self.ed_url.text().strip()
        if not url:
            return
        self.upd_status.setText("…")
        QApplication.processEvents()
        try:
            m = licensing.fetch_manifest(url)
        except Exception as e:  # noqa
            self.upd_status.setText(f"{self.t('error')}: {e}")
            return
        if licensing.update_available(m):
            if QMessageBox.question(self, self.t("upd_tab"),
                                    self.t("update_found").format(v=m["version"])) == QMessageBox.Yes:
                try:
                    v = licensing.install_update(m)
                    security.audit(f"YANGILANISH: {v} o‘rnatildi")
                    self.upd_status.setText(self.t("update_done").format(v=v))
                except Exception as e:  # noqa
                    self.upd_status.setText(f"{self.t('error')}: {e}")
        else:
            self.upd_status.setText(self.t("no_update"))

    def _save(self):
        s = self._sec()
        s["autolock_min"] = self.sp_lock.value()
        s["offline_only"] = self.cb_off.isChecked()
        s["settings_locked"] = self.cb_lock.isChecked()
        s["update_url"] = self.ed_url.text().strip()
        s["auto_update"] = self.cb_auto.isChecked()
        s["require_license"] = self.cb_lic.isChecked()
        self.S["security"] = s
        security.audit("ADMIN: sozlamalar saqlandi")
        self.win.apply_policies()
        self.accept()

    def _logout(self):
        self.win.admin_mode = False
        self.win.apply_policies()
        security.audit("ADMIN: chiqdi")
        self.accept()


def background_manifest_check(settings, on_result):
    """Fon rejimida manifestni tekshiradi: bloklash va yangilanish."""
    url = settings["security"].get("update_url", "")
    if not url or not licensing.is_configured() or settings["security"].get("offline_only"):
        return

    def run():
        try:
            m = licensing.fetch_manifest(url)
        except Exception:
            return
        on_result(m)
    threading.Thread(target=run, daemon=True).start()
