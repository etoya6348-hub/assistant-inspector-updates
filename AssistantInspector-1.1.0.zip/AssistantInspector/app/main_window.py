# -*- coding: utf-8 -*-
import copy
import datetime as dt
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QDate, QEvent, QObject, Qt, QThread, QTime, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPixmap
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QColorDialog, QComboBox, QDateEdit, QDialog,
    QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
    QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QRadioButton, QScrollArea,
    QTabWidget, QTimeEdit, QVBoxLayout, QWidget)

from . import admin as ADM
from . import audio as A
from . import docgen, licensing, security, stt
from .config import (APP_NAME, APP_VERSION, PRESET_COLORS, RANKS, UNITS, Settings, base_dir,
                     data_dir, load_templates, models_dir, templates_path)
from .i18n import LANG_NAMES, I18N
from .themes import build_qss
from .translit import convert

PERSON_FIELDS = ["fio", "birth_date", "birth_place", "nationality", "citizenship", "education",
                 "work", "address", "phone", "family", "id_document", "criminal",
                 "rel_accused", "rel_victim", "deputy"]
PERSON_HINTS = {"citizenship": "Oʻzbekiston Respublikasi", "id_document": "Fuqarolik pasporti",
                "criminal": "Muqaddam sudlanmagan", "deputy": "Deputat emas", "nationality": "Oʻzbek",
                "birth_date": "17.07.1982", "phone": "+998 90 123-45-67"}
WHISPER_MODELS = ["rubaistt_v2_medium_ct2", "large-v3", "large-v3-turbo", "medium"]
DOC_LABEL = {"explanation": "Tushuntirish xati", "witness": "Guvoh soʻroq bayonnomasi",
             "victim": "Jabrlanuvchi soʻroq bayonnomasi", "accused": "Ayblanuvchi soʻroq bayonnomasi"}


def open_path(path):
    path = str(path)
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def safe_name(s):
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', " ", (s or "").strip())
    return re.sub(r"\s+", " ", s).strip(" .")[:120]


def unique_path(folder: Path, stem: str, ext: str) -> Path:
    p = folder / f"{stem}{ext}"
    n = 2
    while p.exists():
        p = folder / f"{stem} ({n}){ext}"
        n += 1
    return p


# ======================================================================= #
class TranscribeWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(str, str)
    failed = Signal(str)

    def __init__(self, audio, settings, script):
        super().__init__()
        self.audio, self.settings, self.script = audio, settings, script

    def run(self):
        try:
            text, used = stt.transcribe(self.audio, self.settings, self.script,
                                        progress=lambda v, m: self.progress.emit(v, m))
            self.finished.emit(text, used)
        except Exception as e:  # noqa
            self.failed.emit(str(e))


def hbox(*widgets, spacing=8, margins=(0, 0, 0, 0)):
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(*margins)
    lay.setSpacing(spacing)
    for x in widgets:
        if x == "stretch":
            lay.addStretch(1)
        else:
            lay.addWidget(x)
    return w


class Card(QFrame):
    def __init__(self, name="card"):
        super().__init__()
        self.setObjectName(name)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(16, 14, 16, 16)
        self.lay.setSpacing(10)


class GrowText(QPlainTextEdit):
    def __init__(self, min_h=60):
        super().__init__()
        self.setMinimumHeight(min_h)
        self.setMaximumHeight(int(min_h * 1.6))


class QACard(Card):
    removed = Signal(object)

    def __init__(self, win, idx):
        super().__init__()
        self.win = win
        self.title = QLabel()
        self.title.setObjectName("h2")
        self.btn_del = QPushButton("✕")
        self.btn_del.setObjectName("ghost")
        self.btn_del.clicked.connect(lambda: self.removed.emit(self))
        self.lay.addWidget(hbox(self.title, "stretch", self.btn_del))
        self.q = GrowText(52)
        self.a = GrowText(70)
        self.q.textChanged.connect(win.touch)
        self.a.textChanged.connect(win.touch)
        self.mic_q = win.make_small_mic(self.q)
        self.mic_a = win.make_small_mic(self.a)
        self.lbl_q, self.lbl_a = QLabel(), QLabel()
        self.lbl_q.setObjectName("muted")
        self.lbl_a.setObjectName("muted")
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.addWidget(self.lbl_q, 0, 0, 1, 2)
        grid.addWidget(self.q, 1, 0)
        grid.addWidget(self.mic_q, 1, 1, Qt.AlignTop)
        grid.addWidget(self.lbl_a, 2, 0, 1, 2)
        grid.addWidget(self.a, 3, 0)
        grid.addWidget(self.mic_a, 3, 1, Qt.AlignTop)
        self.lay.addLayout(grid)
        self.set_index(idx)

    def set_index(self, idx):
        self.idx = idx
        self.retranslate()

    def retranslate(self):
        t = self.win.t
        self.title.setText(f"{t('question')} №{self.idx}")
        self.lbl_q.setText(t("question"))
        self.lbl_a.setText(t("answer"))
        self.mic_q.setToolTip(t("rec_question"))
        self.mic_a.setToolTip(t("rec_answer"))
        self.btn_del.setToolTip(t("remove"))


class CategoryDialog(QDialog):
    def __init__(self, win, current):
        super().__init__(win)
        t = win.t
        self.setWindowTitle(t("choose_category_title"))
        self.choice = current
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 22)
        lay.setSpacing(14)
        lbl = QLabel(t("choose_category_text"))
        lbl.setObjectName("h2")
        lay.addWidget(lbl)
        row = QHBoxLayout()
        for key, icon in (("victim", "🛡"), ("witness", "👁"), ("accused", "⚖")):
            b = QPushButton(f"{icon}\n{t(key)}")
            b.setObjectName("seg")
            b.setMinimumSize(150, 90)
            b.setCheckable(True)
            b.setChecked(key == current)
            b.clicked.connect(lambda _=False, k=key: self._pick(k))
            row.addWidget(b)
        lay.addLayout(row)

    def _pick(self, k):
        self.choice = k
        self.accept()


class ActivityFilter(QObject):
    """Foydalanuvchi faolligini kuzatadi (avtomatik qulflash uchun)."""

    def __init__(self, win):
        super().__init__()
        self.win = win

    def eventFilter(self, obj, ev):
        if ev.type() in (QEvent.MouseButtonPress, QEvent.KeyPress, QEvent.Wheel):
            self.win.last_activity = time.time()
        return False


# ======================================================================= #
#                               Asosiy oyna                                #
# ======================================================================= #
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = Settings()
        self.t = I18N(self.settings["ui_lang"])
        self._tr = []
        self.recorder = None
        self.rec_target = None
        self.rec_button = None
        self.thread = None
        self.online = None
        self.doc_type = "explanation"
        self.category = "witness"
        self.qa_cards = []
        self.cases = {"explanation": None, "protocol": None}
        self.started = {"explanation": None, "protocol": None}
        self.session_audio = []
        self._loading = False
        self.admin_mode = False
        self.locked = False
        self.last_activity = time.time()
        self.last_audio = None
        self.last_target = None

        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1360, 860)
        self.setMinimumSize(1000, 680)

        central = QWidget()
        central.setObjectName("central")
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_rail())
        self.sidebar = self._build_sidebar()
        self.sidebar.setVisible(False)
        root.addWidget(self.sidebar)
        self.main_area = self._build_main()
        root.addWidget(self.main_area, 1)

        self.status = self.statusBar()
        self.apply_theme()
        self.retranslate()
        self.load_draft()
        self._show_case(self.doc_type)
        self.apply_policies()

        self.rec_timer = QTimer(self)
        self.rec_timer.timeout.connect(self._tick_recording)
        self.net_timer = QTimer(self)
        self.net_timer.timeout.connect(self._check_net)
        self.net_timer.start(15000)
        self._check_net()
        self.idle_timer = QTimer(self)
        self.idle_timer.timeout.connect(self._check_idle)
        self.idle_timer.start(20000)
        self._act = ActivityFilter(self)
        QApplication.instance().installEventFilter(self._act)
        security.audit("DASTUR: ishga tushdi")

    # ------------------------------------------------------------------ #
    def startup_checks(self):
        """Ishga tushishda: PIN, obuna, bloklash/yangilanish tekshiruvi."""
        sec = self.settings["security"]
        if sec.get("pin_hash"):
            if not ADM.ask_password(self, self.t, sec["pin_hash"], self.t("locked_title"),
                                    self.t("enter_pin"), can_exit=True):
                return False
        if sec.get("require_license") and licensing.is_configured():
            ok, _ = licensing.check_license(security.decrypt_text(sec.get("license_key", "")),
                                            security.device_id())
            if not ok and not ADM.LicenseDialog(self, self.t, self.settings).exec():
                return False
        ADM.background_manifest_check(self.settings, self._manifest_signal)
        return True

    def _manifest_signal(self, m):
        QTimer.singleShot(0, lambda: self._on_manifest(m))

    def _on_manifest(self, m):
        if security.device_id() in (m.get("blocked_devices") or []):
            security.audit("BLOK: qurilma admin tomonidan bloklangan")
            QMessageBox.critical(self, APP_NAME, self.t("blocked"))
            QApplication.instance().quit()
            return
        if m.get("message"):
            self.status.showMessage(m["message"], 20000)
        if self.settings["security"].get("auto_update") and licensing.update_available(m):
            if QMessageBox.question(self, APP_NAME,
                                    self.t("update_found").format(v=m["version"])) == QMessageBox.Yes:
                try:
                    v = licensing.install_update(m)
                    security.audit(f"YANGILANISH: {v} o‘rnatildi")
                    QMessageBox.information(self, APP_NAME, self.t("update_done").format(v=v))
                except Exception as e:  # noqa
                    QMessageBox.warning(self, self.t("error"), str(e))

    def _check_idle(self):
        sec = self.settings["security"]
        mins = int(sec.get("autolock_min") or 0)
        if self.locked or not mins or not sec.get("pin_hash"):
            return
        if self.recorder is not None and self.recorder.active:
            return
        if time.time() - self.last_activity > mins * 60:
            self.locked = True
            self.centralWidget().setVisible(False)
            security.audit("QULF: harakatsizlik sababli")
            ok = ADM.ask_password(self, self.t, sec["pin_hash"], self.t("locked_title"),
                                  self.t("enter_pin"), can_exit=True, attempts=1000)
            if not ok:
                self.close()
                return
            self.centralWidget().setVisible(True)
            self.locked = False
            self.last_activity = time.time()

    # ------------------------------------------------------------------ #
    def tr(self, fn, key):
        self._tr.append((fn, key))
        return fn

    def label(self, key, obj=None):
        lbl = QLabel()
        if obj:
            lbl.setObjectName(obj)
        self.tr(lbl.setText, key)
        return lbl

    def retranslate(self):
        self.t.lang = self.settings["ui_lang"]
        for fn, key in self._tr:
            try:
                fn(self.t(key))
            except RuntimeError:
                pass
        for c in self.qa_cards:
            c.retranslate()
        for i, key in enumerate(["tab_person", "tab_record", "tab_qa"]):
            self.tabs.setTabText(i, f"{i + 1}. {self.t(key)}")
        self._fill_combos()
        self._update_net_pill()
        self._update_mic_state()

    def ui_conv(self, s):
        """Kirill/lotin matnni interfeys tiliga mos ko‘rsatish."""
        lang = self.settings["ui_lang"]
        if lang == "uz_latn":
            return convert(s, "latn")
        if lang == "uz_cyrl":
            return convert(s, "cyrl")
        return s

    # ============================== RAIL ================================ #
    def _build_rail(self):
        rail = QFrame()
        rail.setObjectName("rail")
        rail.setFixedWidth(64)
        v = QVBoxLayout(rail)
        v.setContentsMargins(8, 14, 8, 12)
        v.setSpacing(10)
        logo = QLabel()
        icon_png = base_dir() / "assets" / "icon.png"
        if icon_png.exists():
            logo.setPixmap(QPixmap(str(icon_png)).scaled(44, 44, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo.setAlignment(Qt.AlignCenter)
        v.addWidget(logo)
        v.addSpacing(10)
        self.btn_gear = QPushButton("⚙")
        self.btn_gear.setObjectName("railBtn")
        self.btn_gear.setCheckable(True)
        self.btn_gear.setFixedSize(48, 48)
        self.btn_gear.clicked.connect(self._toggle_settings)
        self.tr(self.btn_gear.setToolTip, "settings")
        v.addWidget(self.btn_gear, 0, Qt.AlignHCenter)
        self.btn_folder = QPushButton("📁")
        self.btn_folder.setObjectName("railBtn")
        self.btn_folder.setFixedSize(48, 48)
        self.btn_folder.clicked.connect(self._open_results)
        self.tr(self.btn_folder.setToolTip, "results_dir")
        v.addWidget(self.btn_folder, 0, Qt.AlignHCenter)
        v.addStretch(1)
        self.btn_admin_rail = QPushButton("🔐")
        self.btn_admin_rail.setObjectName("railBtn")
        self.btn_admin_rail.setFixedSize(48, 48)
        self.btn_admin_rail.clicked.connect(self.admin_login)
        self.tr(self.btn_admin_rail.setToolTip, "admin_login")
        v.addWidget(self.btn_admin_rail, 0, Qt.AlignHCenter)
        ver = QLabel(f"v{APP_VERSION}")
        ver.setObjectName("railVer")
        ver.setAlignment(Qt.AlignCenter)
        v.addWidget(ver)
        return rail

    def _toggle_settings(self):
        self.sidebar.setVisible(self.btn_gear.isChecked())

    def results_dir(self) -> Path:
        d = Path(self.settings["output_dir"])
        (d / "Audio").mkdir(parents=True, exist_ok=True)
        (d / "Word").mkdir(parents=True, exist_ok=True)
        return d

    def _open_results(self):
        open_path(self.results_dir())

    # ======================== SOZLAMALAR PANELI ======================== #
    def _build_sidebar(self):
        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(340)
        outer = QVBoxLayout(side)
        outer.setContentsMargins(0, 0, 0, 0)
        head = QWidget()
        hl = QHBoxLayout(head)
        hl.setContentsMargins(18, 16, 12, 6)
        names = QVBoxLayout()
        names.setSpacing(0)
        n1 = QLabel("⚙  ")
        n1.setObjectName("brand")
        self.tr(lambda s: n1.setText("⚙  " + s), "settings")
        n2 = QLabel("Assistant Inspector")
        n2.setObjectName("brandSub")
        names.addWidget(n1)
        names.addWidget(n2)
        hl.addLayout(names, 1)
        b_close = QPushButton("✕")
        b_close.setObjectName("ghost")
        b_close.clicked.connect(lambda: (self.btn_gear.setChecked(False), self._toggle_settings()))
        hl.addWidget(b_close, 0, Qt.AlignTop)
        outer.addWidget(head)

        scroll = QScrollArea()
        scroll.setObjectName("sidebarScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(16, 6, 16, 16)
        lay.setSpacing(10)
        scroll.setWidget(body)
        outer.addWidget(scroll, 1)
        S = self.settings

        # --- Ko'rinish ---
        lay.addWidget(self.label("appearance", "sectionTitle"))
        c = Card("sideCard")
        c.lay.addWidget(self.label("theme_color"))
        sw_row = QHBoxLayout()
        sw_row.setSpacing(8)
        self.swatches = []
        for i, pc in enumerate(PRESET_COLORS):
            b = QPushButton()
            b.setObjectName("swatch")
            b.setCheckable(True)
            b.setFixedSize(34, 34)
            b.clicked.connect(lambda _=False, k=i: self._pick_theme(k))
            self.tr(b.setToolTip, "theme_" + pc["key"])
            self.swatches.append(b)
            sw_row.addWidget(b)
        sw_row.addStretch(1)
        c.lay.addLayout(sw_row)
        b_edit = QPushButton()
        b_edit.setObjectName("ghost")
        self.tr(b_edit.setText, "edit_color")
        b_edit.clicked.connect(self._edit_color)
        b_reset = QPushButton()
        b_reset.setObjectName("ghost")
        self.tr(b_reset.setText, "reset_colors")
        b_reset.clicked.connect(self._reset_colors)
        c.lay.addWidget(hbox(b_edit, b_reset, "stretch", spacing=2))
        c.lay.addWidget(self.label("mode"))
        self.btn_light, self.btn_dark = QPushButton(), QPushButton()
        for b, key, dark in ((self.btn_light, "light", False), (self.btn_dark, "dark", True)):
            b.setObjectName("seg")
            b.setCheckable(True)
            self.tr(lambda s, b=b, ic=("🌙 " if dark else "☀ "): b.setText(ic + s), key)
            b.clicked.connect(lambda _=False, d=dark: self._set_dark(d))
        g = QButtonGroup(self)
        g.addButton(self.btn_light)
        g.addButton(self.btn_dark)
        (self.btn_dark if S["dark"] else self.btn_light).setChecked(True)
        c.lay.addWidget(hbox(self.btn_light, self.btn_dark))
        lay.addWidget(c)

        # --- Til ---
        lay.addWidget(self.label("ui_language", "sectionTitle"))
        c = Card("sideCard")
        self.cmb_lang = QComboBox()
        for code, name in LANG_NAMES:
            self.cmb_lang.addItem(name, code)
        self.cmb_lang.setCurrentIndex([c_ for c_, _ in LANG_NAMES].index(S["ui_lang"]))
        self.cmb_lang.currentIndexChanged.connect(self._lang_changed)
        c.lay.addWidget(self.cmb_lang)
        c.lay.addWidget(self.label("doc_script"))
        self.rb_latn, self.rb_cyrl = QRadioButton(), QRadioButton()
        self.tr(self.rb_latn.setText, "latin")
        self.tr(self.rb_cyrl.setText, "cyrillic")
        (self.rb_cyrl if S["doc_script"] == "cyrl" else self.rb_latn).setChecked(True)
        self.rb_latn.toggled.connect(lambda on: on and self._set("doc_script", "latn"))
        self.rb_cyrl.toggled.connect(lambda on: on and self._set("doc_script", "cyrl"))
        c.lay.addWidget(hbox(self.rb_latn, self.rb_cyrl, "stretch", spacing=18))
        lay.addWidget(c)

        # --- Qulf eslatmasi ---
        self.lock_note = self.label("settings_locked_note", "lockNote")
        self.lock_note.setWordWrap(True)
        lay.addWidget(self.lock_note)

        # --- STT ---
        self.lockable = []
        lay.addWidget(self.label("stt_section", "sectionTitle"))
        c = Card("sideCard")
        self.lockable.append(c)
        c.lay.addWidget(self.label("stt_mode"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.currentIndexChanged.connect(
            lambda i: i >= 0 and self._set("stt_mode", self.cmb_mode.itemData(i)))
        c.lay.addWidget(self.cmb_mode)
        c.lay.addWidget(self.label("offline_engine"))
        self.cmb_off = QComboBox()
        self.cmb_off.currentIndexChanged.connect(
            lambda i: i >= 0 and self._set("offline_engine", self.cmb_off.itemData(i)))
        c.lay.addWidget(self.cmb_off)
        c.lay.addWidget(self.label("whisper_model"))
        self.cmb_wmodel = QComboBox()
        self.cmb_wmodel.setEditable(True)
        names_ = list(WHISPER_MODELS)
        for p in sorted(models_dir().glob("*")):
            if p.is_dir() and p.name not in names_ and not p.name.startswith(("vosk", ".", "models--")):
                names_.append(p.name)
        self.cmb_wmodel.addItems(names_)
        self.cmb_wmodel.setCurrentText(S["whisper_model"])
        self.cmb_wmodel.currentTextChanged.connect(lambda s: self._set("whisper_model", s.strip()))
        c.lay.addWidget(self.cmb_wmodel)
        c.lay.addWidget(self.label("precision"))
        self.cmb_prec = QComboBox()
        self.cmb_prec.currentIndexChanged.connect(
            lambda i: i >= 0 and self._set("whisper_compute", self.cmb_prec.itemData(i)))
        c.lay.addWidget(self.cmb_prec)
        c.lay.addWidget(self.label("online_engine"))
        self.cmb_on = QComboBox()
        self.cmb_on.currentIndexChanged.connect(self._online_engine_changed)
        c.lay.addWidget(self.cmb_on)
        self.lbl_key = self.label("api_key")
        self.ed_key = QLineEdit(security.decrypt_text(S["openai_key"]))
        self.ed_key.setEchoMode(QLineEdit.Password)
        self.ed_key.setPlaceholderText("sk-…")
        self.ed_key.editingFinished.connect(
            lambda: self._set("openai_key", security.encrypt_text(self.ed_key.text().strip())))
        c.lay.addWidget(self.lbl_key)
        c.lay.addWidget(self.ed_key)
        c.lay.addWidget(self.label("microphone"))
        self.cmb_mic = QComboBox()
        self.cmb_mic.currentIndexChanged.connect(
            lambda i: i >= 0 and self._set("mic_device", self.cmb_mic.itemData(i)))
        c.lay.addWidget(self.cmb_mic)
        lay.addWidget(c)

        # --- Xodim ma'lumotlari ---
        lay.addWidget(self.label("staff_section", "sectionTitle"))
        c = Card("sideCard")
        self.lockable.append(c)
        inv = S["investigator"]
        self.inv_edits = {}
        c.lay.addWidget(self.label("org_base", "muted"))
        e = QLineEdit(inv.get("org_base", ""))
        e.editingFinished.connect(lambda e=e: self._set_nested("investigator", "org_base", e.text()))
        self.inv_edits["org_base"] = e
        c.lay.addWidget(e)
        c.lay.addWidget(self.label("unit", "muted"))
        self.cmb_unit = QComboBox()
        self.cmb_unit.currentIndexChanged.connect(self._unit_changed)
        c.lay.addWidget(self.cmb_unit)
        self.ed_unit_custom = QLineEdit(inv.get("unit_custom", ""))
        self.tr(self.ed_unit_custom.setPlaceholderText, "unit_custom")
        self.ed_unit_custom.editingFinished.connect(
            lambda: self._set_nested("investigator", "unit_custom", self.ed_unit_custom.text()))
        c.lay.addWidget(self.ed_unit_custom)
        c.lay.addWidget(self.label("position", "muted"))
        e = QLineEdit(inv.get("position", ""))
        e.editingFinished.connect(lambda e=e: self._set_nested("investigator", "position", e.text()))
        self.inv_edits["position"] = e
        c.lay.addWidget(e)
        c.lay.addWidget(self.label("rank", "muted"))
        self.cmb_rank = QComboBox()
        self.cmb_rank.currentIndexChanged.connect(
            lambda i: i >= 0 and self._set_nested("investigator", "rank", self.cmb_rank.itemData(i)))
        c.lay.addWidget(self.cmb_rank)
        for key, lk in (("fio", "inv_fio"), ("place", "place")):
            c.lay.addWidget(self.label(lk, "muted"))
            e = QLineEdit(inv.get(key, ""))
            e.editingFinished.connect(lambda k=key, e=e: self._set_nested("investigator", k, e.text()))
            self.inv_edits[key] = e
            c.lay.addWidget(e)
        lay.addWidget(c)

        lay.addWidget(self.label("addressee_section", "sectionTitle"))
        c = Card("sideCard")
        self.lockable.append(c)
        self.addr_edits = {}
        for key, lk in (("position", "addr_position"), ("fio", "addr_fio")):
            c.lay.addWidget(self.label(lk, "muted"))
            e = QLineEdit(S["addressee"].get(key, ""))
            e.editingFinished.connect(lambda k=key, e=e: self._set_nested("addressee", k, e.text()))
            self.addr_edits[key] = e
            c.lay.addWidget(e)
        lay.addWidget(c)

        # --- Papkalar / andozalar ---
        lay.addWidget(self.label("results_dir", "sectionTitle"))
        c = Card("sideCard")
        lbl = QLabel(str(Path(S["output_dir"])))
        lbl.setObjectName("muted")
        lbl.setWordWrap(True)
        c.lay.addWidget(lbl)
        b = QPushButton()
        self.tr(lambda s: b.setText("📁 " + s), "open")
        b.clicked.connect(self._open_results)
        c.lay.addWidget(b)
        b2 = QPushButton()
        b2.setObjectName("ghost")
        self.tr(b2.setText, "open_andoza")
        b2.clicked.connect(lambda: open_path(base_dir() / "andozalar"))
        c.lay.addWidget(b2)
        bt = QPushButton()
        bt.setObjectName("ghost")
        self.tr(bt.setText, "templates_edit")
        bt.clicked.connect(lambda: (load_templates(), open_path(templates_path())))
        self.lockable.append(bt)
        c.lay.addWidget(bt)
        lay.addWidget(c)

        # --- Admin ---
        self.btn_admin = QPushButton()
        self.btn_admin.setObjectName("admin")
        self.tr(lambda s: self.btn_admin.setText("🔐 " + s), "admin_login")
        self.btn_admin.clicked.connect(self.admin_login)
        lay.addWidget(self.btn_admin)
        lay.addStretch(1)
        for cmb in body.findChildren(QComboBox):
            cmb.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            cmb.setMinimumContentsLength(8)
        for e in body.findChildren(QLineEdit):
            e.setMinimumWidth(50)
        body.setMaximumWidth(340 - 14)
        return side

    # ============================ ASOSIY QISM =========================== #
    def _build_main(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(22, 18, 22, 12)
        lay.setSpacing(12)

        top = Card()
        head = QHBoxLayout()
        head.addWidget(self.label("doc_type", "h1"))
        head.addStretch(1)
        self.pill = QLabel()
        head.addWidget(self.pill)
        top.lay.addLayout(head)
        self.btn_expl, self.btn_prot = QPushButton(), QPushButton()
        g = QButtonGroup(self)
        for b, key, icon in ((self.btn_expl, "explanation", "📝 "), (self.btn_prot, "protocol", "📋 ")):
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setMinimumHeight(44)
            self.tr(lambda s, b=b, ic=icon: b.setText(ic + s), key)
            b.clicked.connect(lambda _=False, k=key: self.switch_doc_type(k))
            g.addButton(b)
        top.lay.addWidget(hbox(self.btn_expl, self.btn_prot))
        self.cat_row = QWidget()
        cl = QVBoxLayout(self.cat_row)
        cl.setContentsMargins(0, 4, 0, 0)
        cl.addWidget(self.label("category", "muted"))
        self.cat_btns = {}
        g2 = QButtonGroup(self)
        row = []
        for key, icon in (("victim", "🛡 "), ("witness", "👁 "), ("accused", "⚖ ")):
            b = QPushButton()
            b.setObjectName("seg")
            b.setCheckable(True)
            self.tr(lambda s, b=b, ic=icon: b.setText(ic + s), key)
            b.clicked.connect(lambda _=False, k=key: self._set_category(k))
            g2.addButton(b)
            self.cat_btns[key] = b
            row.append(b)
        cl.addWidget(hbox(*row))
        top.lay.addWidget(self.cat_row)
        lay.addWidget(top)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._tab_person(), "")
        self.tabs.addTab(self._tab_record(), "")
        self.tabs.addTab(self._tab_qa(), "")
        lay.addWidget(self.tabs, 1)

        b_new = QPushButton()
        self.tr(lambda s: b_new.setText("＋ " + s), "new_case")
        b_new.clicked.connect(self.new_case)
        b_open = QPushButton()
        self.tr(lambda s: b_open.setText("📁 " + s), "open_folder")
        b_open.clicked.connect(self._open_results)
        b_save = QPushButton()
        b_save.setObjectName("primary")
        b_save.setMinimumHeight(40)
        self.tr(lambda s: b_save.setText("💾 " + s), "save_docx")
        b_save.clicked.connect(self.save_docx)
        lay.addWidget(hbox(b_new, b_open, "stretch", b_save))
        return w

    # ---------------------------- 1-tab -------------------------------- #
    def _tab_person(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(2, 12, 8, 8)
        lay.setSpacing(12)
        scroll.setWidget(body)
        card = Card()
        self.person_grid = QGridLayout()
        self.person_grid.setHorizontalSpacing(16)
        self.person_grid.setVerticalSpacing(6)
        self.person, self.person_labels = {}, {}
        for key in PERSON_FIELDS:
            lbl = self.label(key, "muted")
            e = QLineEdit()
            if key in PERSON_HINTS:
                e.setPlaceholderText(PERSON_HINTS[key])
            e.textEdited.connect(self.touch)
            self.person[key] = e
            self.person_labels[key] = lbl
        card.lay.addLayout(self.person_grid)
        lay.addWidget(card)

        self.session_card = Card()
        self.session_card.lay.addWidget(self.label("session", "h2"))
        self.ed_date = QDateEdit(QDate.currentDate())
        self.ed_date.setCalendarPopup(True)
        self.ed_date.setDisplayFormat("dd.MM.yyyy")
        self.ed_start = QTimeEdit(QTime.currentTime())
        self.ed_end = QTimeEdit(QTime.currentTime())
        for te in (self.ed_start, self.ed_end):
            te.setDisplayFormat("HH:mm")
        self.ed_place = QLineEdit(self.settings["investigator"].get("place", ""))
        g = QGridLayout()
        g.setHorizontalSpacing(12)
        for col, (k, wdg) in enumerate((("date", self.ed_date), ("start_time", self.ed_start),
                                        ("end_time", self.ed_end), ("place", self.ed_place))):
            g.addWidget(self.label(k, "muted"), 0, col)
            g.addWidget(wdg, 1, col)
        g.setColumnStretch(3, 1)
        self.session_card.lay.addLayout(g)
        lay.addWidget(self.session_card)

        self.accused_card = Card()
        self.accused_card.lay.addWidget(self.label("accused_section", "h2"))
        self.ed_charge = QLineEdit()
        self.ed_charge.setPlaceholderText("168-moddasi 3-qismi")
        self.ed_charge_date = QDateEdit(QDate.currentDate())
        self.ed_charge_date.setCalendarPopup(True)
        self.ed_charge_date.setDisplayFormat("dd.MM.yyyy")
        self.cmb_plea = QComboBox()
        self.ed_defender = QLineEdit()
        g = QGridLayout()
        g.setHorizontalSpacing(12)
        for col, (k, wdg) in enumerate((("charge_article", self.ed_charge), ("charge_date", self.ed_charge_date),
                                        ("plea", self.cmb_plea), ("defender", self.ed_defender))):
            g.addWidget(self.label(k, "muted"), 0, col)
            g.addWidget(wdg, 1, col)
        g.setColumnStretch(0, 2)
        g.setColumnStretch(3, 2)
        self.accused_card.lay.addLayout(g)
        lay.addWidget(self.accused_card)

        self.options_card = Card()
        self.options_card.lay.addWidget(self.label("options", "h2"))
        self.chk_lawyer, self.chk_health, self.chk_vol = QCheckBox(), QCheckBox(), QCheckBox()
        for cb, k in ((self.chk_lawyer, "lawyer_refused"), (self.chk_health, "include_health"),
                      (self.chk_vol, "include_voluntary")):
            self.tr(cb.setText, k)
            self.options_card.lay.addWidget(cb)
        lay.addWidget(self.options_card)
        lay.addStretch(1)
        return scroll

    # ---------------------------- 2-tab -------------------------------- #
    def _tab_record(self):
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(2, 12, 2, 2)
        lay.setSpacing(14)
        left = Card()
        left.setFixedWidth(300)
        left.lay.setAlignment(Qt.AlignTop)
        self.mic_big = QPushButton("🎙")
        self.mic_big.setObjectName("micBig")
        self.mic_big.setFixedSize(104, 104)
        self.mic_big.clicked.connect(lambda: self.toggle_record(self.narrative, self.mic_big))
        left.lay.addWidget(self.mic_big, 0, Qt.AlignHCenter)
        self.lbl_mic_state = QLabel()
        self.lbl_mic_state.setAlignment(Qt.AlignCenter)
        self.lbl_mic_state.setWordWrap(True)
        left.lay.addWidget(self.lbl_mic_state)
        self.lbl_time = QLabel("00:00")
        self.lbl_time.setObjectName("recTime")
        self.lbl_time.setAlignment(Qt.AlignCenter)
        left.lay.addWidget(self.lbl_time)
        self.level = QProgressBar()
        self.level.setObjectName("level")
        self.level.setRange(0, 100)
        self.level.setFixedHeight(10)
        left.lay.addWidget(self.level)
        self.btn_pause = QPushButton()
        self.btn_pause.setEnabled(False)
        self.btn_pause.clicked.connect(self._toggle_pause)
        self.tr(self.btn_pause.setText, "pause")
        left.lay.addWidget(self.btn_pause)
        b_imp = QPushButton()
        self.tr(lambda s: b_imp.setText("🎵 " + s), "import_audio")
        b_imp.clicked.connect(self.import_audio)
        left.lay.addWidget(b_imp)
        self.btn_retry = QPushButton()
        self.tr(lambda s: self.btn_retry.setText("🔁 " + s), "retry")
        self.btn_retry.setVisible(False)
        self.btn_retry.clicked.connect(self._retry)
        left.lay.addWidget(self.btn_retry)
        left.lay.addSpacing(8)
        self.lbl_target = QLabel()
        self.lbl_target.setObjectName("muted")
        self.lbl_target.setWordWrap(True)
        left.lay.addWidget(self.lbl_target)
        self.prog = QProgressBar()
        self.prog.setRange(0, 100)
        self.prog.setVisible(False)
        left.lay.addWidget(self.prog)
        self.lbl_prog = QLabel()
        self.lbl_prog.setObjectName("muted")
        self.lbl_prog.setWordWrap(True)
        left.lay.addWidget(self.lbl_prog)
        lay.addWidget(left)

        right = Card()
        right.lay.addWidget(self.label("narrative", "h2"))
        hint = self.label("narrative_hint", "muted")
        hint.setWordWrap(True)
        right.lay.addWidget(hint)
        self.narrative = QPlainTextEdit()
        self.narrative.setFont(QFont("Times New Roman", 13))
        self.narrative.textChanged.connect(self.touch)
        right.lay.addWidget(self.narrative, 1)
        b_clear = QPushButton()
        b_clear.setObjectName("ghost")
        self.tr(b_clear.setText, "clear")
        b_clear.clicked.connect(self.narrative.clear)
        right.lay.addWidget(hbox("stretch", b_clear))
        lay.addWidget(right, 1)
        return w

    # ---------------------------- 3-tab -------------------------------- #
    def _tab_qa(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(2, 12, 2, 2)
        hint = self.label("qa_hint", "muted")
        hint.setWordWrap(True)

        # Mikrofon holati (ovoz tembri) — "Savol qo‘shish" tugmasi tepasida
        mic_box = Card("sideCard")
        mic_box.lay.setContentsMargins(12, 8, 12, 10)
        mic_box.lay.setSpacing(6)
        mic_box.setFixedWidth(300)
        self.qa_mic_state = QLabel()
        self.qa_mic_state.setObjectName("muted")
        self.qa_level = QProgressBar()
        self.qa_level.setObjectName("level")
        self.qa_level.setRange(0, 100)
        self.qa_level.setFixedHeight(10)
        mic_box.lay.addWidget(self.qa_mic_state)
        mic_box.lay.addWidget(self.qa_level)
        b_add = QPushButton()
        b_add.setObjectName("primary")
        b_add.setMinimumHeight(38)
        self.tr(lambda s: b_add.setText("＋ " + s), "qa_add")
        b_add.clicked.connect(lambda: self.add_qa(scroll=True))
        mic_box.lay.addWidget(b_add)
        lay.addWidget(hbox(hint, "stretch", mic_box))

        self.qa_scroll = QScrollArea()
        self.qa_scroll.setWidgetResizable(True)
        self.qa_host = QWidget()
        self.qa_lay = QVBoxLayout(self.qa_host)
        self.qa_lay.setContentsMargins(0, 4, 8, 4)
        self.qa_lay.setSpacing(10)
        self.qa_lay.addStretch(1)
        self.qa_scroll.setWidget(self.qa_host)
        lay.addWidget(self.qa_scroll, 1)
        return w

    def add_qa(self, q="", a="", scroll=False):
        card = QACard(self, len(self.qa_cards) + 1)
        self._loading, prev = True, self._loading
        card.q.setPlainText(q)
        card.a.setPlainText(a)
        self._loading = prev
        card.removed.connect(self.remove_qa)
        self.qa_lay.insertWidget(self.qa_lay.count() - 1, card)
        self.qa_cards.append(card)
        if scroll:
            def go():
                sb = self.qa_scroll.verticalScrollBar()
                sb.setValue(sb.maximum())
                self.qa_scroll.ensureWidgetVisible(card, 0, 0)
                card.q.setFocus()
            QTimer.singleShot(60, go)
            QTimer.singleShot(200, go)
        return card

    def remove_qa(self, card):
        if self.rec_target in (card.q, card.a):
            return
        self.qa_cards.remove(card)
        card.setParent(None)
        card.deleteLater()
        for i, c in enumerate(self.qa_cards, 1):
            c.set_index(i)

    # ============================ MANTIQ ================================ #
    def _set(self, key, val):
        self.settings[key] = val
        if key == "stt_mode":
            self._update_net_pill()

    def _set_nested(self, sect, key, val):
        d = dict(self.settings[sect])
        d[key] = val.strip() if isinstance(val, str) else val
        self.settings[sect] = d

    def _fill_combos(self):
        t, S = self.t, self.settings

        def fill(cmb, items, current):
            cmb.blockSignals(True)
            cmb.clear()
            for key, data in items:
                cmb.addItem(t(key), data)
            cmb.setCurrentIndex(max(0, cmb.findData(current)))
            cmb.blockSignals(False)

        fill(self.cmb_mode, [("mode_auto", "auto"), ("mode_offline", "offline"), ("mode_online", "online")],
             S["stt_mode"])
        fill(self.cmb_off, [("whisper", "whisper"), ("vosk", "vosk")], S["offline_engine"])
        fill(self.cmb_prec, [("prec_quality", "auto"), ("prec_fast", "int8")], S.get("whisper_compute", "auto"))
        fill(self.cmb_on, [("google", "google"), ("openai", "openai")], S["online_engine"])
        fill(self.cmb_plea, [("plea_yes", "иқрор"), ("plea_no", "иқрор эмас"), ("plea_partial", "қисман иқрор")],
             self.cmb_plea.currentData() or "иқрор")
        fill(self.cmb_unit, [("unit_" + k if k != "custom" else "unit_custom_opt", k) for k, _, _ in UNITS],
             S["investigator"].get("unit", "tb"))
        self.ed_unit_custom.setVisible(S["investigator"].get("unit") == "custom")
        self.cmb_rank.blockSignals(True)
        self.cmb_rank.clear()
        for r in RANKS:
            self.cmb_rank.addItem(self.ui_conv(r), r)
        self.cmb_rank.setCurrentIndex(max(0, self.cmb_rank.findData(S["investigator"].get("rank"))))
        self.cmb_rank.blockSignals(False)
        self.cmb_mic.blockSignals(True)
        self.cmb_mic.clear()
        self.cmb_mic.addItem(t("default_mic"), None)
        for idx, name in A.list_input_devices():
            self.cmb_mic.addItem(name, idx)
        self.cmb_mic.setCurrentIndex(max(0, self.cmb_mic.findData(S["mic_device"])))
        self.cmb_mic.blockSignals(False)
        vis = S["online_engine"] == "openai"
        self.lbl_key.setVisible(vis)
        self.ed_key.setVisible(vis)

    def _unit_changed(self, i):
        if i < 0:
            return
        k = self.cmb_unit.itemData(i)
        self._set_nested("investigator", "unit", k)
        self.ed_unit_custom.setVisible(k == "custom")
        if k == "custom":
            self.ed_unit_custom.setFocus()

    def _online_engine_changed(self, i):
        if i < 0:
            return
        self._set("online_engine", self.cmb_on.itemData(i))
        vis = self.settings["online_engine"] == "openai"
        self.lbl_key.setVisible(vis)
        self.ed_key.setVisible(vis)

    # --- Admin / siyosatlar ---
    def admin_login(self):
        sec = self.settings["security"]
        if not self.admin_mode:
            if not sec.get("admin_hash"):
                d = ADM.PasswordDialog(self, self.t, self.t("admin_login"), self.t("set_admin_pw"), create=True)
                if not d.exec():
                    return
                s = dict(sec)
                s["admin_hash"] = security.hash_password(d.value)
                self.settings["security"] = s
                security.audit("ADMIN: parol o‘rnatildi")
            elif not ADM.ask_password(self, self.t, sec["admin_hash"], self.t("admin_login"),
                                      self.t("password")):
                return
            self.admin_mode = True
            security.audit("ADMIN: kirdi")
            self.apply_policies()
        ADM.AdminPanel(self).exec()

    def apply_policies(self):
        sec = self.settings["security"]
        locked = sec.get("settings_locked") and not self.admin_mode
        for w in self.lockable:
            w.setEnabled(not locked)
        self.lock_note.setVisible(bool(locked))
        if sec.get("offline_only"):
            self.cmb_mode.setCurrentIndex(max(0, self.cmb_mode.findData("offline")))
            self.cmb_mode.setEnabled(False)
        else:
            self.cmb_mode.setEnabled(not locked)
        self.btn_admin.setText(("🔓 " if self.admin_mode else "🔐 ") +
                               self.t("admin_panel" if self.admin_mode else "admin_login"))
        self._update_net_pill()

    # --- Mavzu ---
    def apply_theme(self):
        S = self.settings
        colors, idx = S["theme_colors"], S["theme_index"]
        QApplication.instance().setStyleSheet(build_qss(colors[idx], S["dark"]))
        for i, b in enumerate(self.swatches):
            b.setStyleSheet(f"background:{colors[i]};")
            b.setChecked(i == idx)

    def _pick_theme(self, i):
        self.settings["theme_index"] = i
        self.apply_theme()

    def _edit_color(self):
        i = self.settings["theme_index"]
        colors = list(self.settings["theme_colors"])
        c = QColorDialog.getColor(QColor(colors[i]), self, self.t("edit_color"))
        if c.isValid():
            colors[i] = c.name()
            self.settings["theme_colors"] = colors
            self.apply_theme()

    def _reset_colors(self):
        self.settings["theme_colors"] = [c["color"] for c in PRESET_COLORS]
        self.apply_theme()

    def _set_dark(self, d):
        self.settings["dark"] = d
        (self.btn_dark if d else self.btn_light).setChecked(True)
        self.apply_theme()

    def _lang_changed(self, i):
        self.settings["ui_lang"] = self.cmb_lang.itemData(i)
        self.retranslate()
        self.apply_policies()

    # ===================== Hujjat turi / holatlar ====================== #
    def empty_case(self, doc_type):
        return {"doc_type": doc_type, "category": "witness", "person": {}, "narrative": "", "qa": [],
                "date": "", "start_time": "", "end_time": "", "place": "", "accused": {},
                "lawyer_refused": True, "include_health": True, "include_voluntary": False,
                "started": None}

    def form_to_case(self):
        return {
            "doc_type": self.doc_type,
            "category": self.category,
            "person": {k: e.text().strip() for k, e in self.person.items()},
            "narrative": self.narrative.toPlainText(),
            "qa": [{"q": c.q.toPlainText(), "a": c.a.toPlainText()} for c in self.qa_cards],
            "date": self.ed_date.date().toString("dd.MM.yyyy"),
            "start_time": self.ed_start.time().toString("HH:mm"),
            "end_time": self.ed_end.time().toString("HH:mm"),
            "place": self.ed_place.text().strip(),
            "accused": {"charge_article": self.ed_charge.text().strip(),
                        "charge_date": self.ed_charge_date.date().toString("dd.MM.yyyy"),
                        "plea": self.cmb_plea.currentData() or "иқрор",
                        "defender": self.ed_defender.text().strip()},
            "lawyer_refused": self.chk_lawyer.isChecked(),
            "include_health": self.chk_health.isChecked(),
            "include_voluntary": self.chk_vol.isChecked(),
            "started": self.started.get(self.doc_type),
        }

    def case_to_form(self, c):
        self._loading = True
        try:
            for k, e in self.person.items():
                e.setText(c.get("person", {}).get(k, ""))
            self.narrative.setPlainText(c.get("narrative", ""))
            for card in list(self.qa_cards):
                self.qa_cards.remove(card)
                card.setParent(None)
                card.deleteLater()
            for qa in c.get("qa", []):
                self.add_qa(qa.get("q", ""), qa.get("a", ""))
            d = QDate.fromString(c.get("date") or "", "dd.MM.yyyy")
            self.ed_date.setDate(d if d.isValid() else QDate.currentDate())
            for te, key in ((self.ed_start, "start_time"), (self.ed_end, "end_time")):
                tm = QTime.fromString(c.get(key) or "", "HH:mm")
                te.setTime(tm if tm.isValid() else QTime.currentTime())
            self.ed_place.setText(c.get("place") or self.settings["investigator"].get("place", ""))
            acc = c.get("accused", {})
            self.ed_charge.setText(acc.get("charge_article", ""))
            self.ed_defender.setText(acc.get("defender", ""))
            i = self.cmb_plea.findData(acc.get("plea"))
            self.cmb_plea.setCurrentIndex(max(0, i))
            self.chk_lawyer.setChecked(c.get("lawyer_refused", True))
            self.chk_health.setChecked(c.get("include_health", True))
            self.chk_vol.setChecked(c.get("include_voluntary", False))
            self.category = c.get("category", self.category)
            self.started[c.get("doc_type", self.doc_type)] = c.get("started")
        finally:
            self._loading = False

    def switch_doc_type(self, k):
        if k == self.doc_type:
            self._show_case(k, ask=(k == "protocol"))
            return
        if self.recorder is not None and self.recorder.active:
            self._show_case(self.doc_type)
            return
        self.cases[self.doc_type] = self.form_to_case()
        self.doc_type = k
        self.case_to_form(self.cases.get(k) or self.empty_case(k))
        self._show_case(k, ask=(k == "protocol"))
        self.tabs.setCurrentIndex(0)

    def _show_case(self, k, ask=False):
        self.btn_expl.setChecked(k == "explanation")
        self.btn_prot.setChecked(k == "protocol")
        if k == "protocol" and ask:
            dlg = CategoryDialog(self, self.category)
            if dlg.exec():
                self.category = dlg.choice
        self.cat_row.setVisible(k == "protocol")
        self._set_category(self.category)

    def _set_category(self, k):
        self.category = k
        for key, b in self.cat_btns.items():
            b.setChecked(key == k)
        prot = self.doc_type == "protocol"
        acc = prot and k == "accused"
        self.session_card.setVisible(prot)
        self.accused_card.setVisible(acc)
        self.options_card.setVisible(prot)
        self.chk_lawyer.setVisible(prot and not acc)
        self.chk_health.setVisible(prot and not acc)
        self._relayout_person(prot)

    def _relayout_person(self, prot):
        g = self.person_grid
        while g.count():
            g.takeAt(0)
        only_prot = ("citizenship", "id_document", "rel_accused", "rel_victim", "deputy")
        i = 0
        for key in PERSON_FIELDS:
            vis = prot or key not in only_prot
            self.person[key].setVisible(vis)
            self.person_labels[key].setVisible(vis)
            if not vis:
                continue
            r, col = divmod(i, 2)
            g.addWidget(self.person_labels[key], r * 2, col)
            g.addWidget(self.person[key], r * 2 + 1, col)
            i += 1

    def touch(self, *_):
        """Hujjatni to‘ldirish boshlangan vaqtni avtomatik qayd etadi."""
        if self._loading or self.started.get(self.doc_type):
            return
        now = dt.datetime.now()
        self.started[self.doc_type] = now.strftime("%H:%M")
        self.ed_start.setTime(QTime(now.hour, now.minute))
        self.ed_date.setDate(QDate.currentDate())

    # --- Internet holati ---
    def _check_net(self):
        def run():
            self.online = stt.is_online()
        threading.Thread(target=run, daemon=True).start()
        QTimer.singleShot(2000, self._update_net_pill)

    def _update_net_pill(self):
        if self.online is None:
            self.pill.setText("…")
            return
        mode = "offline" if self.settings["security"].get("offline_only") else self.settings["stt_mode"]
        on = self.online and mode != "offline"
        self.pill.setObjectName("pillOnline" if on else "pillOffline")
        mtxt = {"auto": "", "offline": " · " + self.t("mode_offline"),
                "online": " · " + self.t("mode_online")}[mode]
        self.pill.setText(("● " if on else "○ ") +
                          self.t("status_online" if self.online else "status_offline") + mtxt)
        self.pill.style().unpolish(self.pill)
        self.pill.style().polish(self.pill)

    # ============================ OVOZ YOZISH =========================== #
    def make_small_mic(self, target):
        b = QPushButton("🎙")
        b.setObjectName("micSmall")
        b.setFixedSize(32, 32)
        b.clicked.connect(lambda: self.toggle_record(target, b))
        return b

    def _set_rec_prop(self, btn, on):
        btn.setProperty("recording", "true" if on else "false")
        btn.style().unpolish(btn)
        btn.style().polish(btn)
        if btn is not self.mic_big:
            btn.setText("■" if on else "🎙")

    def _target_name(self):
        if self.rec_target is self.narrative:
            return self.t("narrative")
        for c in self.qa_cards:
            if self.rec_target is c.q:
                return f"{self.t('question')} №{c.idx}"
            if self.rec_target is c.a:
                return f"{self.t('answer')} №{c.idx}"
        return "—"

    def _update_mic_state(self):
        rec = self.recorder is not None and self.recorder.active
        self.mic_big.setText("■" if rec and self.rec_button is self.mic_big else "🎙")
        self.lbl_mic_state.setText(self.t("stop") if rec else self.t("record"))
        self.lbl_target.setText(f"{self.t('rec_target')} {self._target_name()}" if rec else "")
        if not rec:
            self.qa_mic_state.setText("🎙 " + self.t("mic_idle"))
            self.qa_level.setValue(0)

    def toggle_record(self, target, button):
        if self.thread is not None:
            return
        if self.recorder is not None and self.recorder.active:
            if button is self.rec_button:
                self.stop_record()
            return
        try:
            self.recorder = A.Recorder(self.settings["mic_device"])
            self.recorder.start()
        except Exception as e:  # noqa
            self.recorder = None
            QMessageBox.warning(self, self.t("error"), f"{self.t('mic_error')}:\n{e}")
            return
        self.touch()
        self.rec_target, self.rec_button = target, button
        self._set_rec_prop(button, True)
        if button is not self.mic_big:
            self._set_rec_prop(self.mic_big, True)
        self.btn_pause.setEnabled(True)
        self.rec_timer.start(100)
        self.status.showMessage(self.t("recording") + "…")
        self._update_mic_state()

    def _toggle_pause(self):
        if not self.recorder:
            return
        self.recorder.paused = not self.recorder.paused
        self.btn_pause.setText(self.t("resume") if self.recorder.paused else self.t("pause"))

    def _tick_recording(self):
        if not self.recorder or not self.recorder.active:
            return
        sec = int(time.time() - self.recorder.started_at)
        tm = f"{sec // 60:02d}:{sec % 60:02d}"
        lv = int(self.recorder.level * 100)
        self.lbl_time.setText(tm)
        self.level.setValue(lv)
        self.qa_level.setValue(lv)
        self.qa_mic_state.setText(f"🔴 {self.t('recording')} {tm} — {self._target_name()}")

    def _audio_stem(self):
        fio = safe_name(self.person["fio"].text())
        return fio or "Nomaʼlum shaxs"

    def stop_record(self):
        audio = self.recorder.stop()
        self.rec_timer.stop()
        self.level.setValue(0)
        self.btn_pause.setEnabled(False)
        self.btn_pause.setText(self.t("pause"))
        self._set_rec_prop(self.rec_button, False)
        self._set_rec_prop(self.mic_big, False)
        try:
            adir = self.results_dir() / "Audio"
            fpath = unique_path(adir, self._audio_stem(), ".wav")
            A.save_wav(fpath, audio)
            self.session_audio.append(fpath)
            security.audit("AUDIO: yozuv saqlandi")
            self.status.showMessage(f"{self.t('audio_saved')} {fpath}", 8000)
        except Exception:
            pass
        target = self.rec_target
        self._update_mic_state()
        self.start_transcribe(audio, target)

    def import_audio(self):
        if self.thread is not None or (self.recorder and self.recorder.active):
            return
        adir = self.results_dir() / "Audio"
        path, _ = QFileDialog.getOpenFileName(
            self, self.t("import_audio"), str(adir),
            "Audio (*.wav *.mp3 *.m4a *.ogg *.oga *.opus *.amr *.aac *.flac *.wma *.webm *.mp4);;*.*")
        if not path:
            return
        try:
            audio = A.load_audio(path)
        except Exception as e:  # noqa
            QMessageBox.warning(self, self.t("error"), str(e))
            return
        self.tabs.setCurrentIndex(1)
        self.start_transcribe(audio, self.narrative)

    def _retry(self):
        if self.thread is None and self.last_audio is not None:
            self.btn_retry.setVisible(False)
            self.start_transcribe(self.last_audio, self.last_target or self.narrative)

    def _stt_settings(self):
        s = copy.deepcopy(self.settings.data)
        s["openai_key"] = security.decrypt_text(s.get("openai_key", ""))
        if s["security"].get("offline_only"):
            s["stt_mode"] = "offline"
        return s

    def start_transcribe(self, audio, target):
        self.last_audio, self.last_target = audio, target
        self.rec_target = target
        self.prog.setVisible(True)
        self.prog.setRange(0, 0)
        self.lbl_prog.setText(self.t("transcribing"))
        self.qa_mic_state.setText("⏳ " + self.t("transcribing"))
        self.mic_big.setEnabled(False)
        self.thread = QThread()
        self.worker = TranscribeWorker(audio, self._stt_settings(), self.settings["doc_script"])
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_text)
        self.worker.failed.connect(self._on_fail)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self._thread_done)
        self.thread.start()

    def _on_progress(self, v, msg):
        if v < 0:
            self.prog.setRange(0, 0)
            self.lbl_prog.setText(self.t("loading_model"))
        else:
            self.prog.setRange(0, 100)
            self.prog.setValue(v)
            self.lbl_prog.setText(f"{self.t('transcribing')} {v}%")
            self.qa_mic_state.setText(f"⏳ {self.t('transcribing')} {v}%")

    def _on_text(self, text, used):
        tgt = self.rec_target or self.narrative
        if not text:
            self.lbl_prog.setText(self.t("no_text"))
            return
        cur = tgt.toPlainText().rstrip()
        tgt.setPlainText((cur + ("\n" if tgt is self.narrative else " ") if cur else "") + text)
        tgt.moveCursor(tgt.textCursor().MoveOperation.End)
        self.btn_retry.setVisible(False)
        names = {"online:google": "Google", "online:openai": "OpenAI",
                 "offline:whisper": "Whisper (offline)", "offline:vosk": "Vosk (offline)"}
        msg = f"{self.t('done_with')} {names.get(used, used)}"
        self.lbl_prog.setText(msg)
        self.status.showMessage(msg, 8000)

    def _on_fail(self, msg):
        self.lbl_prog.setText(self.t("error") + " — " + self.t("retry_hint"))
        self.btn_retry.setVisible(True)
        QMessageBox.warning(self, self.t("error"), msg)

    def _thread_done(self):
        self.prog.setVisible(False)
        self.mic_big.setEnabled(True)
        self.thread.deleteLater()
        self.thread = None
        self.rec_target = None
        self.rec_button = None
        self._update_mic_state()

    # ============================ HUJJAT ================================ #
    def collect_case(self):
        c = self.form_to_case()
        c["investigator"] = dict(self.settings["investigator"])
        c["investigator"].update({k: e.text().strip() for k, e in self.inv_edits.items()})
        c["investigator"]["unit_custom"] = self.ed_unit_custom.text().strip()
        c["addressee"] = {k: e.text().strip() for k, e in self.addr_edits.items()}
        c["place"] = c["place"] or c["investigator"].get("place", "")
        c["script"] = self.settings["doc_script"]
        return c

    def _rename_session_audio(self):
        stem = self._audio_stem()
        if stem == "Nomaʼlum shaxs":
            return
        new = []
        for p in self.session_audio:
            try:
                if p.exists() and p.stem.startswith("Nomaʼlum shaxs"):
                    np_ = unique_path(p.parent, stem, p.suffix)
                    p.rename(np_)
                    p = np_
            except Exception:
                pass
            new.append(p)
        self.session_audio = new

    def save_docx(self):
        if self.doc_type == "protocol":
            now = QTime.currentTime()
            self.ed_end.setTime(QTime(now.hour(), now.minute()))
            if not self.started.get("protocol"):
                self.touch()
        case = self.collect_case()
        wdir = self.results_dir() / "Word"
        k = "explanation" if self.doc_type == "explanation" else self.category
        stem = safe_name(case["person"]["fio"]) or "Nomaʼlum shaxs"
        path = unique_path(wdir, f"{stem} - {DOC_LABEL[k]}", ".docx")
        T = load_templates()
        try:
            andoza = base_dir() / "andozalar" / "tushuntirish_xati.docx"
            if self.doc_type == "explanation" and andoza.exists():
                docgen.render_explanation_template(case, T, andoza, path, case["script"])
            else:
                docgen.render_docx(docgen.build_blocks(case, T), path, case["script"])
        except PermissionError:
            QMessageBox.warning(self, self.t("error"), str(path))
            return
        except Exception as e:  # noqa
            QMessageBox.warning(self, self.t("error"), str(e))
            return
        self._rename_session_audio()
        security.audit(f"HUJJAT: {DOC_LABEL[k]} saqlandi")
        self.status.showMessage(f"{self.t('saved_to')} {path}", 12000)
        self.save_draft()
        if self.settings["open_after_save"]:
            open_path(path)

    def new_case(self):
        if QMessageBox.question(self, APP_NAME, self.t("new_case_confirm")) != QMessageBox.Yes:
            return
        self.cases[self.doc_type] = None
        self.started[self.doc_type] = None
        self.case_to_form(self.empty_case(self.doc_type))
        self.started[self.doc_type] = None
        self.session_audio = []
        self.tabs.setCurrentIndex(0)
        self.save_draft()

    # --- Qoralama (shifrlangan) ---
    def _draft_path(self):
        return data_dir() / "draft.enc"

    def save_draft(self):
        try:
            self.cases[self.doc_type] = self.form_to_case()
            security.save_secure_json(self._draft_path(),
                                      {"current": self.doc_type, "cases": self.cases})
        except Exception:
            pass

    def load_draft(self):
        old = data_dir() / "draft.json"
        p = self._draft_path()
        if old.exists():  # eski, shifrlanmagan qoralamani ko‘chirib, xavfsiz o‘chirish
            try:
                import json
                c = json.loads(old.read_text(encoding="utf-8"))
                c.setdefault("doc_type", "explanation")
                c.pop("investigator", None)
                c.pop("addressee", None)
                c["started"] = None
                if not p.exists():
                    security.save_secure_json(p, {"current": c["doc_type"], "cases": {c["doc_type"]: c}})
            except Exception:
                pass
            security.wipe_file(old)
        self.case_to_form(self.empty_case("explanation"))
        if not p.exists():
            return
        try:
            d = security.load_secure_json(p)
        except Exception:
            return
        self.cases = d.get("cases") or self.cases
        self.doc_type = d.get("current", "explanation")
        c = self.cases.get(self.doc_type) or self.empty_case(self.doc_type)
        self.category = c.get("category", "witness")
        self.case_to_form(c)

    def closeEvent(self, ev):
        if self.recorder and self.recorder.active:
            self.recorder.stop()
        self.save_draft()
        security.audit("DASTUR: yopildi")
        super().closeEvent(ev)
