@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Assistant Inspector

if not exist ".venv\Scripts\python.exe" (
    echo [1/2] Birinchi ishga tushirish: muhit tayyorlanmoqda...
    where py >nul 2>nul && (py -3 -m venv .venv) || (python -m venv .venv)
    if not exist ".venv\Scripts\python.exe" (
        echo.
        echo Python topilmadi. https://www.python.org/downloads/ dan Python 3.11-3.13 ni
        echo o'rnating ^("Add python.exe to PATH" belgisini qo'ying^) va qayta urinib ko'ring.
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
)
rem Kutubxonalar ro'yxati o'zgargan bo'lsa (yangilanishdan keyin) - o'rnatish
fc /b requirements.txt ".venv\req.txt" >nul 2>nul
if errorlevel 1 (
    echo Kerakli kutubxonalar o'rnatilmoqda ^(internet kerak^)...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (pause & exit /b 1)
    copy /y requirements.txt ".venv\req.txt" >nul
)
start "" ".venv\Scripts\pythonw.exe" main.py
