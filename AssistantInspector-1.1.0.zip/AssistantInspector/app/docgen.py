# -*- coding: utf-8 -*-
"""Tushuntirish xati va so‘roq bayonnomasini shakllantirish (DOCX + HTML ko‘rinish)."""
import datetime as _dt
import html
import re

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

from .translit import convert

MONTHS_CYR = ["январь", "февраль", "март", "апрель", "май", "июнь", "июль",
              "август", "сентябрь", "октябрь", "ноябрь", "декабрь"]

SIGN_LINE = "_________"
FONT = "Times New Roman"


# --------------------------------------------------------------------- #
#                             Yordamchilar                              #
# --------------------------------------------------------------------- #
def _clean(s):
    return (s or "").strip()


def _lc1(s: str) -> str:
    """Faqat birinchi harfni kichik qiladi (joy nomlari katta harfda qoladi)."""
    return s[:1].lower() + s[1:] if s else s


def initials(fio: str, full=True) -> str:
    """'Назаров Алишер Мирзаевич' -> 'А.М.Назаров' (full) yoki 'А.Назаров'."""
    parts = [p for p in re.split(r"\s+", _clean(fio)) if p]
    if not parts:
        return "__________"
    if len(parts) == 1:
        return parts[0]
    surname, rest = parts[0], parts[1:]
    letters = [rest[0][0].upper()]
    if full and len(rest) > 1:
        letters.append(rest[1][0].upper())
    return ".".join(letters) + "." + surname


def parse_date(s):
    s = _clean(s)
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return _dt.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def long_date(d: _dt.date) -> str:
    return f"{d.year} йил {d.day} {MONTHS_CYR[d.month - 1]}"


def split_paragraphs(text):
    text = (text or "").replace("\r", "")
    return [p.strip() for p in re.split(r"\n+", text) if p.strip()]


# --------------------------------------------------------------------- #
#                 Bloklar (umumiy, keyin DOCX/HTML ga)                   #
# --------------------------------------------------------------------- #
class P:
    """Paragraf: runs = [(matn, qalin)]"""

    def __init__(self, runs, align="justify", indent=True, size=14, left=0.0,
                 kind="text", space_after=0):
        if isinstance(runs, str):
            runs = [(runs, False)]
        self.runs = runs
        self.align = align
        self.indent = indent
        self.size = size
        self.left = left
        self.kind = kind  # text | sign | dateplace
        self.space_after = space_after


class Table:
    def __init__(self, rows):
        self.rows = rows  # [(n, label, value)]


def sign(role, name):
    return P([(f"{role}\t{SIGN_LINE}\t{name}", True)], kind="sign")


def qa_blocks(q, a, signer=None, blank_answer=False):
    q = q_text(q)
    out = [P([("Савол: ", True), (q, True)])]
    if blank_answer:
        out.append(P([("Жавоб:", True), ("_" * 50, False)]))
        out.append(P([("_" * 64, False)], indent=False))
    else:
        out.append(P([("Жавоб: ", True), (a or "", False)]))
    if signer:
        out.append(signer)
    return out


# --------------------------------------------------------------------- #
#                         Tushuntirish xati                              #
# --------------------------------------------------------------------- #
def build_explanation(case, T):
    t = T["explanation"]
    per = case["person"]
    addr = case.get("addressee", {})
    fio = _clean(per.get("fio")) or "__________"
    short = initials(fio, full=False)
    blocks = []

    hdr_left = 10.0
    if _clean(addr.get("position")):
        blocks.append(P([(_clean(addr["position"]), True)], indent=False, left=hdr_left, align="left"))
    if _clean(addr.get("fio")):
        blocks.append(P([(_clean(addr["fio"]), True)], indent=False, left=hdr_left, align="right"))
    from_line = ""
    if _clean(per.get("address")):
        a = re.sub(r"[\s,]*(да|da)?\s*(яшайди|yashaydi)\.?$", "", _clean(per["address"]), flags=re.I)
        from_line = a.rstrip(" .,") + "да яшовчи "
    from_line += fio + "дан"
    blocks.append(P(from_line, indent=False, left=hdr_left, align="left"))
    if _clean(per.get("phone")):
        blocks.append(P(_clean(per["phone"]), indent=False, left=hdr_left, align="left"))
    blocks.append(P("", indent=False))
    blocks.append(P([(t["title"], True)], align="center", indent=False))
    blocks.append(P("", indent=False))

    vals = {
        "fio": fio,
        "birth_date": _clean(per.get("birth_date")) or "______",
        "birth_place": _clean(per.get("birth_place")) or "______",
        "nationality": _lc1(_clean(per.get("nationality")) or "______"),
        "education": _lc1(_clean(per.get("education")) or "______"),
        "family": _lc1(_clean(per.get("family")) or "______"),
        "criminal": _lc1(_clean(per.get("criminal")) or "муқаддам судланмаганман"),
        "work": _clean(per.get("work")) or "______",
    }
    intro = case.get("intro_override") or t["intro"].format(**vals)
    blocks.append(P(intro))
    blocks.append(P(t["warning"]))
    signer = sign("", short)
    blocks.append(signer)

    paras = split_paragraphs(case.get("narrative"))
    first = t["narrative_intro"] + (paras[0] if paras else "")
    blocks.append(P(first))
    for p in paras[1:]:
        blocks.append(P(p))
    if paras:
        blocks.append(sign("", short))

    for qa in case.get("qa", []):
        if _clean(qa.get("q")) or _clean(qa.get("a")):
            blocks += qa_blocks(_clean(qa.get("q")), _clean(qa.get("a")), sign("", short))
    blocks.append(P([("_" * 64, False)], indent=False))
    return blocks


# --------------------------------------------------------------------- #
#                         So‘roq bayonnomasi                            #
# --------------------------------------------------------------------- #
def build_protocol(case, T):
    cat = case.get("category", "witness")
    c = T["protocol_common"]
    t = T[cat]
    per = case["person"]
    inv = case.get("investigator", {})
    fio = _clean(per.get("fio")) or "__________"
    ini = initials(fio)
    inv_ini = initials(inv.get("fio", ""))
    role = t["role"]
    blocks = []

    for line in split_paragraphs(org_header(inv) or inv.get("org", "")):
        blocks.append(P([(line.upper(), True)], align="center", indent=False))
    blocks.append(P("", indent=False))
    for line in t["title"].split("\n"):
        blocks.append(P([(line, True)], align="center", indent=False))
    blocks.append(P("", indent=False))

    d = parse_date(case.get("date")) or _dt.date.today()
    date_txt = c["header_date"].format(year=d.year, day=f"{d.day:02d}", month=MONTHS_CYR[d.month - 1])
    blocks.append(P([(date_txt + "\t" + _clean(case.get("place")), False)], kind="dateplace", indent=False))
    blocks.append(P("", indent=False))

    blocks.append(P(c["intro"].format(
        position=_clean(inv.get("position")), rank=_clean(inv.get("rank")),
        investigator=inv_ini, articles=t["articles"],
        person_acc=ini + "ни", role_inst=t["role_inst"])))
    blocks.append(P("", indent=False))
    blocks.append(P([(c["times"].format(start=_clean(case.get("start_time")) or "__:__",
                                         end=_clean(case.get("end_time")) or "__:__"), True)],
                    align="center", indent=False, size=13))
    blocks.append(P("", indent=False))

    rows = []
    for i, (key, label) in enumerate(c["table_rows"], 1):
        val = _clean(per.get(key))
        if key == "birth_date" and val and re.fullmatch(r"[\d./-]+", val):
            val += " йилда туғилган"
        if key == "address" and _clean(per.get("phone")):
            val = (val + ". " if val else "") + "Тел: " + _clean(per["phone"])
        rows.append((str(i), label, val))
    blocks.append(Table(rows))
    blocks.append(P("", indent=False))

    blocks.append(P([(t["rights_header"], True)]))
    for r in t["rights"]:
        blocks.append(P(r, size=13))
    blocks.append(P(t["rights_explained"].format(initials=ini, initials_dat=ini + "га")))
    s = sign(role + ":", ini)
    blocks.append(s)

    if cat == "accused":
        acc = case.get("accused", {})
        cd = parse_date(acc.get("charge_date")) or d
        plea = _clean(acc.get("plea")) or "иқрор"
        blocks.append(P(t["charge"].format(
            position=_clean(inv.get("position")), rank=_clean(inv.get("rank")),
            investigator_gen=inv_ini + "нинг", charge_date=long_date(cd),
            charge_article=_clean(acc.get("charge_article")) or "____-моддаси",
            plea="________" + plea + "________")))
        blocks.append(sign(role + ":", ini))

    blocks += qa_blocks(*c["q_language"], signer=sign(role + ":", ini))
    blocks += qa_blocks(*c["q_alphabet"], signer=sign(role + ":", ini))
    if t.get("lawyer_paragraph") and case.get("lawyer_refused", True):
        blocks.append(P(c["lawyer_refusal"].format(article=t["rights_article"])))
        blocks.append(sign(role + ":", ini))
    blocks += qa_blocks(*c["q_computer"], signer=sign(role + ":", ini))

    paras = split_paragraphs(case.get("narrative"))
    if t.get("health_paragraph") and case.get("include_health", True):
        paras = [c["health"]] + paras
    first = t["narrative_intro"] + (" " + paras[0] if paras else "")
    blocks.append(P(first))
    for p in paras[1:]:
        blocks.append(P(p))

    for qa in case.get("qa", []):
        if _clean(qa.get("q")) or _clean(qa.get("a")):
            blocks += qa_blocks(_clean(qa.get("q")), _clean(qa.get("a")))

    if case.get("include_voluntary", cat == "accused"):
        blocks += qa_blocks(c["q_voluntary"], "", signer=sign(role + ":", ini), blank_answer=True)
    blocks += qa_blocks(c["q_final"], "", signer=sign(role + ":", ini), blank_answer=True)

    if cat == "accused" and _clean(case.get("accused", {}).get("defender")):
        blocks.append(sign(c["defender"], initials(case["accused"]["defender"])))
    blocks.append(sign(c["signed_by"], inv_ini))
    return blocks


def build_blocks(case, templates):
    if case.get("doc_type") == "explanation":
        return build_explanation(case, templates)
    return build_protocol(case, templates)


# --------------------------------------------------------------------- #
#                             DOCX render                               #
# --------------------------------------------------------------------- #
def _set_cell_border(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
        borders.append(el)
    tblPr.append(borders)


def _font(run, size, bold=False):
    run.font.name = FONT
    run.font.size = Pt(size)
    run.bold = bold
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(a), FONT)


_ALIGN = {"justify": WD_ALIGN_PARAGRAPH.JUSTIFY, "center": WD_ALIGN_PARAGRAPH.CENTER,
          "left": WD_ALIGN_PARAGRAPH.LEFT, "right": WD_ALIGN_PARAGRAPH.RIGHT}


def render_docx(blocks, path, script="latn"):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin, sec.right_margin = Cm(3), Cm(1.5)
    sec.top_margin, sec.bottom_margin = Cm(2), Cm(2)
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.font.size = Pt(14)
    st.paragraph_format.space_after = Pt(0)
    st.paragraph_format.space_before = Pt(0)
    st.paragraph_format.line_spacing = 1.0

    for b in blocks:
        if isinstance(b, Table):
            tbl = doc.add_table(rows=0, cols=3)
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            tbl.autofit = False
            _set_cell_border(tbl)
            widths = (Cm(1.0), Cm(6.5), Cm(9.0))
            grid = tbl._tbl.tblGrid
            for gc, w in zip(grid.findall(qn("w:gridCol")), widths):
                gc.set(qn("w:w"), str(int(w.twips)))
            for n, label, val in b.rows:
                cells = tbl.add_row().cells
                for cell, txt, w in zip(cells, (n, label, val), widths):
                    cell.width = w
                    p = cell.paragraphs[0]
                    _font(p.add_run(convert(txt, script)), 14)
            continue
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.space_after = Pt(b.space_after)
        if b.kind == "sign":
            pf.first_line_indent = Cm(1.25)
            pf.tab_stops.add_tab_stop(Cm(5.5))
            pf.tab_stops.add_tab_stop(Cm(10.5))
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        elif b.kind == "dateplace":
            pf.tab_stops.add_tab_stop(Cm(16.5), WD_TAB_ALIGNMENT.RIGHT)
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        else:
            p.alignment = _ALIGN[b.align]
            if b.indent:
                pf.first_line_indent = Cm(1.25)
        if b.left:
            pf.left_indent = Cm(b.left)
        for txt, bold in b.runs:
            _font(p.add_run(convert(txt, script)), b.size, bold)
    doc.save(path)
    return path


# --------------------------------------------------------------------- #
#                         HTML (ko‘rib chiqish)                         #
# --------------------------------------------------------------------- #
def render_html(blocks, script="latn"):
    out = ['<div style="font-family:\'Times New Roman\',serif;font-size:14pt;color:#111111;">']
    for b in blocks:
        if isinstance(b, Table):
            out.append('<table border="1" cellspacing="0" cellpadding="4" width="100%" '
                       'style="border-collapse:collapse;border-color:#555;font-size:13pt;color:#111111">')
            for n, label, val in b.rows:
                out.append("<tr>" + "".join(
                    f'<td width="{w}">{html.escape(convert(x, script))}</td>'
                    for x, w in zip((n, label, val), ("5%", "38%", "57%"))) + "</tr>")
            out.append("</table>")
            continue
        align = {"justify": "justify", "center": "center", "left": "left", "right": "right"}[b.align]
        style = f"margin:0;text-align:{align};font-size:{b.size}pt;color:#111111;"
        if b.indent and b.kind == "text":
            style += "text-indent:1.25cm;"
        if b.left:
            style += f"margin-left:{b.left * 0.9:.1f}cm;"
        if b.kind == "dateplace":
            left, _, right = b.runs[0][0].partition("\t")
            out.append('<table width="100%" style="font-size:14pt;color:#111111"><tr>'
                       f'<td>{html.escape(convert(left, script))}</td>'
                       f'<td align="right">{html.escape(convert(right, script))}</td></tr></table>')
            continue
        parts = []
        for txt, bold in b.runs:
            t = html.escape(convert(txt, script))
            t = t.replace("\t", "&nbsp;" * 10)
            parts.append(f"<b>{t}</b>" if bold else t)
        content = "".join(parts) or "&nbsp;"
        if b.kind == "sign":
            style += "padding-left:1.25cm;"
        out.append(f'<p style="{style}">{content}</p>')
    out.append("</div>")
    return "\n".join(out)


# --------------------------------------------------------------------- #
#             Savol oxirida "?" bo‘lishi, sarlavha (bo‘linma)            #
# --------------------------------------------------------------------- #
def q_text(q: str) -> str:
    q = re.sub(r"[\s.,;:!?…]+$", "", (q or "").strip())
    return q + "?" if q else ""


def org_header(inv: dict) -> str:
    from .config import UNITS
    base = _clean(inv.get("org_base"))
    unit = inv.get("unit", "tb")
    if unit == "custom":
        u = _clean(inv.get("unit_custom"))
    else:
        u = dict((k, h) for k, _, h in UNITS).get(unit, "")
    if base and u:
        return f"{base} ҳузуридаги {u}"
    return base or u


# --------------------------------------------------------------------- #
#        Tushuntirish xati — foydalanuvchi namunasi (andoza) asosida      #
#   Namunadagi abzas, shrift, oraliq va boshqa formatlar o‘zgarmaydi.    #
# --------------------------------------------------------------------- #
from copy import deepcopy  # noqa: E402


def _is_bold(r):
    rpr = r.find(qn("w:rPr"))
    if rpr is None:
        return False
    b = rpr.find(qn("w:b"))
    return b is not None and b.get(qn("w:val")) not in ("0", "false")


def _run_text(r):
    return "".join(t.text or "" for t in r.iter(qn("w:t")))


def _pick_rpr(p, bold):
    runs = p.findall(qn("w:r"))
    for r in runs:
        if _is_bold(r) == bold and _run_text(r).strip():
            rpr = r.find(qn("w:rPr"))
            return deepcopy(rpr) if rpr is not None else None
    for r in runs:
        rpr = r.find(qn("w:rPr"))
        if rpr is not None:
            rpr = deepcopy(rpr)
            b = rpr.find(qn("w:b"))
            if not bold and b is not None:
                rpr.remove(b)
            if bold and b is None:
                rpr.append(OxmlElement("w:b"))
            return rpr
    return None


def _fill(proto, segments, script):
    """proto paragrafining nusxasini olib, matnni almashtiradi (pPr va rPr saqlanadi).
    segments: [(matn, qalinmi)]"""
    el = deepcopy(proto)
    rpr = {True: _pick_rpr(proto, True), False: _pick_rpr(proto, False)}
    for child in list(el):
        if child.tag != qn("w:pPr"):
            el.remove(child)
    for text, bold in segments:
        text = convert(text, script)
        r = OxmlElement("w:r")
        if rpr[bold] is not None:
            r.append(deepcopy(rpr[bold]))
        parts = re.split(r"(\t|\n)", text)
        for part in parts:
            if part == "\t":
                r.append(OxmlElement("w:tab"))
            elif part == "\n":
                r.append(OxmlElement("w:br"))
            elif part:
                t = OxmlElement("w:t")
                t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                t.text = part
                r.append(t)
        el.append(r)
    return el


def _ptext(p):
    return "".join(_run_text(r) for r in p.findall(qn("w:r")))


def _segments(p):
    """Paragrafni (matn, qalin) bo‘laklariga ajratadi (ketma-ket bir xil qalinlikdagi runlar birlashadi)."""
    segs = []
    for r in p.findall(qn("w:r")):
        txt = ""
        for ch in r:
            if ch.tag == qn("w:t"):
                txt += ch.text or ""
            elif ch.tag == qn("w:tab"):
                txt += "\t"
            elif ch.tag == qn("w:br"):
                txt += "\n"
        if not txt:
            continue
        b = _is_bold(r)
        if segs and segs[-1][1] == b:
            segs[-1] = (segs[-1][0] + txt, b)
        else:
            segs.append((txt, b))
    return segs


def _main_bold(p, skip_label=False):
    segs = _segments(p)
    if skip_label and segs:
        txt = "".join(t for t, _ in segs)
        lab = re.match(r"^\s*\S+?:\s*", txt)
        n = len(lab.group(0)) if lab else 0
        rest = []
        pos = 0
        for t, b in segs:
            if pos + len(t) > n:
                rest.append((t[max(0, n - pos):], b))
            pos += len(t)
        segs = rest
    segs = [(t, b) for t, b in segs if t.strip(" \t_")]
    return segs[0][1] if segs else False


def _classify_all(paras):
    texts = [_ptext(p) for p in paras]
    title_i = next((i for i, t in enumerate(texts)
                    if t.strip().lower() in ("тушунтириш хати", "tushuntirish xati")), None)
    if title_i is None:
        raise ValueError("Andozada 'Тушунтириш хати' sarlavhasi topilmadi.")
    roles = []
    for i, t in enumerate(texts):
        st, low = t.strip(), t.strip().lower()
        if not st:
            roles.append("blank")
        elif i < title_i:
            if re.match(r"^[+\d(]", st):
                roles.append("phone")
            elif "яшовчи" in low or low.endswith("дан"):
                roles.append("from")
            elif low.endswith("га"):
                roles.append("name")
            else:
                roles.append("pos")
        elif i == title_i:
            roles.append("title")
        elif low.startswith("мен ") and "intro" not in roles:
            roles.append("intro")
        elif low.startswith("менга берилган"):
            roles.append("narr")
        elif low.startswith("савол"):
            roles.append("final_q" if "қўшимча" in low or "qoʻshimcha" in low else "q")
        elif low.startswith("жавоб"):
            roles.append("final_a" if roles and roles[-1] == "final_q" else "a")
        elif "тушунтириш" in low and "____" in st and re.search(r"олди(м)?\b|олган", low):
            roles.append("olgan")
        elif "____" in st and len(st.replace(" ", "")) < 40:
            roles.append("sign")
        else:
            roles.append("keep")
    return roles


def render_explanation_template(case, T, template_path, path, script="latn"):
    """Andoza (namuna) hujjatini qadamma-qadam takrorlaydi: doimiy qismlar o‘zgarishsiz
    qoladi, faqat shaxs maʼlumotlari, ko‘rsatuv, savol-javoblar va imzolar almashtiriladi."""
    t = T["explanation"]
    per = case["person"]
    addr = case.get("addressee", {})
    inv = case.get("investigator", {})
    fio = _clean(per.get("fio")) or "__________"
    short = initials(fio, full=False)
    inv_short = initials(inv.get("fio", ""), full=False) if _clean(inv.get("fio")) else "__________"

    doc = Document(str(template_path))
    body = doc.element.body
    paras = body.findall(qn("w:p"))
    roles = _classify_all(paras)
    sect = body.find(qn("w:sectPr"))
    for p in paras:
        body.remove(p)
    out = []

    def emit(proto, segs):
        out.append(_fill(proto, segs, script))

    def keep(proto):
        segs = _segments(proto)
        if segs:
            emit(proto, segs)
        else:
            out.append(deepcopy(proto))

    def full(proto):
        return "".join(x for x, _ in _segments(proto))

    def lead(proto):
        return re.match(r"^[ \t]*", full(proto)).group(0)

    def sign_text(proto, name):
        txt = full(proto).rstrip()
        new, cnt = re.subn(r"(_{3,}[ \t]*)[^\s_]*[ \t]*$", lambda m: m.group(1) + name, txt)
        return new if cnt else txt + " " + name

    vals = {
        "fio": fio,
        "birth_date": _clean(per.get("birth_date")) or "______",
        "birth_place": _clean(per.get("birth_place")) or "______",
        "nationality": _lc1(_clean(per.get("nationality")) or "______"),
        "education": _lc1(_clean(per.get("education")) or "______"),
        "family": _lc1(_clean(per.get("family")) or "______"),
        "criminal": _lc1(_clean(per.get("criminal")) or "муқаддам судланмаганман"),
        "work": _clean(per.get("work")) or "______",
    }
    narr = split_paragraphs(case.get("narrative"))
    qas = [(q_text(x.get("q")), _clean(x.get("a"))) for x in case.get("qa", [])]
    qas = [x for x in qas if x[0] or x[1]]
    qa_done = False
    i, n = 0, len(paras)
    while i < n:
        role, p = roles[i], paras[i]
        b = _main_bold(p)
        if role == "pos":
            if _clean(addr.get("position")):
                emit(p, [(_clean(addr["position"]), b)])
        elif role == "name":
            if _clean(addr.get("fio")):
                emit(p, [(lead(p) + _clean(addr["fio"]), b)])
        elif role == "from":
            a = re.sub(r"[\s,]*(да|da)?\s*(яшайди|yashaydi)\.?$", "", _clean(per.get("address")), flags=re.I)
            emit(p, [((a.rstrip(" .,") + "да яшовчи " if a else "") + fio + "дан", b)])
        elif role == "phone":
            if _clean(per.get("phone")):
                emit(p, [(lead(p) + _clean(per["phone"]), b)])
        elif role == "intro":
            emit(p, [(t["intro"].format(**vals), b)])
        elif role == "narr":
            emit(p, [(t["narrative_intro"].rstrip() + " " + (narr[0] if narr else ""), b)])
            for extra in narr[1:]:
                emit(p, [(extra, b)])
        elif role == "sign":
            emit(p, [(sign_text(p, short), b)])
        elif role in ("q", "a"):
            if not qa_done:
                qa_done = True
                pq = p if role == "q" else None
                j = i
                pa = psign = None
                while j < n and roles[j] not in ("final_q", "olgan"):
                    if roles[j] == "q" and pq is None:
                        pq = paras[j]
                    elif roles[j] == "a" and pa is None:
                        pa = paras[j]
                    elif roles[j] == "sign" and pa is not None and psign is None:
                        psign = paras[j]
                    if pq is not None and pa is not None and psign is not None:
                        break
                    j += 1
                qb = _main_bold(pq, skip_label=True) if pq is not None else True
                ab = _main_bold(pa, skip_label=True) if pa is not None else False
                for q, a in qas:
                    emit(pq if pq is not None else p, [("Савол:", True), (" " + q, qb)])
                    emit(pa if pa is not None else p, [("Жавоб:", True), (" " + a, ab)])
                    if psign is not None:
                        emit(psign, [(sign_text(psign, short), _main_bold(psign))])
            # namunadagi qolgan savol-javob va ularning imzolarini o‘tkazib yuborish
            while i + 1 < n and roles[i + 1] in ("q", "a", "sign"):
                i += 1
        elif role == "final_q":
            segs = _segments(p)
            txt = "".join(x for x, _ in segs)
            m = re.match(r"^\s*Савол:\s*", txt)
            body_q = q_text(txt[m.end():] if m else txt)
            emit(p, [("Савол:", True), (" " + body_q, _main_bold(p, skip_label=True))])
        elif role == "olgan":
            emit(p, [(sign_text(p, inv_short), b)])
        else:
            keep(p)
        i += 1
    for el in out:
        if sect is not None:
            sect.addprevious(el)
        else:
            body.append(el)
    doc.save(str(path))
    return path
