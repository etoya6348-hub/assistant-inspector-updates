@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Assistant Inspector - oflayn modellar
if not exist ".venv\Scripts\python.exe" (
    echo Avval run.bat ni bir marta ishga tushiring.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" download_models.py
