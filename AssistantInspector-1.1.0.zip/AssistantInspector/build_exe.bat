@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Assistant Inspector - EXE yig'ish
if not exist ".venv\Scripts\python.exe" (
    echo Avval run.bat ni bir marta ishga tushiring.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\pyinstaller.exe" --noconfirm --clean --windowed ^
  --name "Assistant Inspector" --icon assets\icon.ico ^
  --add-data "assets;assets" ^
  --collect-all faster_whisper --collect-all ctranslate2 --collect-all vosk ^
  --collect-all speech_recognition --collect-all av ^
  main.py
if exist models xcopy /E /I /Y models "dist\Assistant Inspector\models" >nul
echo.
echo Tayyor: dist\Assistant Inspector\Assistant Inspector.exe
echo Butun "dist\Assistant Inspector" papkasini istalgan kompyuterga ko'chirish mumkin.
pause
