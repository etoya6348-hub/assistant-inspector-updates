# -*- coding: utf-8 -*-
"""Zamonaviy interfeys mavzulari (kunduzgi / tungi + 5 ta asosiy rang)."""
from PySide6.QtGui import QColor

LIGHT = dict(bg="#F4F6FB", surface="#FFFFFF", surface2="#F8FAFC", sidebar="#FFFFFF",
             text="#0F172A", muted="#64748B", border="#E2E8F0", input="#FFFFFF")
DARK = dict(bg="#0B1120", surface="#131C2E", surface2="#1A2438", sidebar="#0F172A",
            text="#E2E8F0", muted="#94A3B8", border="#26324A", input="#0F1829")


def _mix(c1, c2, t):
    a, b = QColor(c1), QColor(c2)
    return QColor(int(a.red() + (b.red() - a.red()) * t),
                  int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t)).name()


def build_qss(accent: str, dark: bool) -> str:
    p = DARK if dark else LIGHT
    acc = QColor(accent).name()
    hover = _mix(acc, "#000000", 0.12) if not dark else _mix(acc, "#FFFFFF", 0.12)
    soft = _mix(acc, p["surface"], 0.86)
    soft2 = _mix(acc, p["surface"], 0.75)
    on_acc = "#FFFFFF"
    panel = _mix(acc, p["bg"], 0.86 if not dark else 0.80)
    panel_card = _mix(acc, p["surface"], 0.94 if not dark else 0.88)
    rail = _mix(acc, "#000000", 0.10) if not dark else _mix(acc, "#000000", 0.45)
    return f"""
* {{ font-family: "Segoe UI", "Inter", "Noto Sans", Arial; font-size: 10pt; color: {p['text']}; }}
QMainWindow, #central {{ background: {p['bg']}; }}
QToolTip {{ background: {p['surface']}; color: {p['text']}; border: 1px solid {p['border']}; padding: 4px; }}

#rail {{ background: {rail}; }}
QPushButton#railBtn {{ background: transparent; border: none; border-radius: 12px; color: #FFFFFF;
    font-size: 18pt; padding: 0; }}
QPushButton#railBtn:hover {{ background: rgba(255,255,255,0.18); color: #FFFFFF; }}
QPushButton#railBtn:checked {{ background: rgba(255,255,255,0.28); color: #FFFFFF; }}
#railVer {{ color: rgba(255,255,255,0.75); font-size: 7.5pt; }}
#sidebar {{ background: {panel}; border-right: 2px solid {acc}; }}
#sidebarScroll, #sidebarScroll > QWidget > QWidget {{ background: {panel}; border: none; }}
#sideCard {{ background: {panel_card}; border: 1px solid {soft2}; border-radius: 12px; }}
#sectionTitle {{ color: {acc}; font-size: 8.5pt; font-weight: 800; letter-spacing: 1px; padding-top: 6px; }}
#lockNote {{ background: #FEF3C7; color: #92400E; border-radius: 8px; padding: 6px 8px; }}
QPushButton#admin {{ background: {p['text']}; color: {p['bg']}; border: none; padding: 9px; }}
QPushButton#admin:hover {{ background: {acc}; color: #FFFFFF; }}
#brand {{ font-size: 15pt; font-weight: 700; color: {p['text']}; }}
#brandSub {{ color: {p['muted']}; font-size: 9pt; }}
#logo {{ background: {acc}; border-radius: 12px; color: {on_acc}; font-size: 15pt; font-weight: 800; }}
#card {{ background: {p['surface']}; border: 1px solid {p['border']}; border-radius: 14px; }}
#muted {{ color: {p['muted']}; }}
#h1 {{ font-size: 16pt; font-weight: 700; }}
#h2 {{ font-size: 11.5pt; font-weight: 650; }}

QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QDateEdit, QTimeEdit {{
    background: {p['input']}; border: 1px solid {p['border']}; border-radius: 9px;
    padding: 6px 9px; selection-background-color: {acc}; selection-color: {on_acc}; }}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QDateEdit:focus, QTimeEdit:focus {{
    border: 1.5px solid {acc}; }}
QComboBox::drop-down, QDateEdit::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {p['surface']}; border: 1px solid {p['border']};
    selection-background-color: {soft}; selection-color: {p['text']}; outline: 0; }}

QPushButton {{ background: {p['surface']}; border: 1px solid {p['border']}; border-radius: 9px;
    padding: 7px 14px; font-weight: 600; }}
QPushButton:hover {{ border-color: {acc}; color: {acc}; }}
QPushButton:disabled {{ color: {p['muted']}; background: {p['surface2']}; }}
QPushButton#primary {{ background: {acc}; color: {on_acc}; border: 1px solid {acc}; }}
QPushButton#primary:hover {{ background: {hover}; border-color: {hover}; color: {on_acc}; }}
QPushButton#ghost {{ background: transparent; border: none; color: {p['muted']}; padding: 4px 8px; }}
QPushButton#ghost:hover {{ color: {acc}; }}

QPushButton#seg {{ background: {p['surface2']}; border: 1px solid {p['border']}; border-radius: 10px;
    padding: 9px 16px; color: {p['muted']}; }}
QPushButton#seg:checked {{ background: {soft}; border: 1.5px solid {acc}; color: {acc}; }}
QPushButton#seg:hover {{ color: {acc}; }}

QPushButton#micBig {{ background: {acc}; border: 6px solid {soft2}; border-radius: 52px; color: {on_acc};
    font-size: 26pt; padding: 0; }}
QPushButton#micBig:hover {{ background: {hover}; color: {on_acc}; }}
QPushButton#micBig[recording="true"] {{ background: #EF4444; border-color: #FECACA; }}
QPushButton#micSmall {{ background: {soft}; border: 1px solid {soft2}; border-radius: 15px; color: {acc};
    padding: 0; font-size: 12pt; }}
QPushButton#micSmall:hover {{ background: {acc}; color: {on_acc}; }}
QPushButton#micSmall[recording="true"] {{ background: #EF4444; color: white; border-color: #EF4444; }}

QPushButton#swatch {{ border-radius: 15px; border: 3px solid {p['sidebar']}; padding: 0; }}
QPushButton#swatch:checked {{ border: 3px solid {p['text']}; }}

#pillOnline {{ background: #DCFCE7; color: #166534; border-radius: 10px; padding: 3px 10px; font-weight: 600; }}
#pillOffline {{ background: #FEF3C7; color: #92400E; border-radius: 10px; padding: 3px 10px; font-weight: 600; }}
#recTime {{ font-size: 22pt; font-weight: 700; font-family: "Consolas", "JetBrains Mono", monospace; }}

QTabWidget::pane {{ border: none; background: transparent; top: -1px; }}
QTabBar::tab {{ background: transparent; color: {p['muted']}; padding: 10px 18px; margin-right: 4px;
    border: none; border-bottom: 3px solid transparent; font-weight: 600; }}
QTabBar::tab:selected {{ color: {acc}; border-bottom: 3px solid {acc}; }}
QTabBar::tab:hover {{ color: {p['text']}; }}

QProgressBar {{ background: {p['surface2']}; border: 1px solid {p['border']}; border-radius: 6px;
    height: 10px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ background: {acc}; border-radius: 5px; }}
QProgressBar#level::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {acc}, stop:1 #EF4444); }}

QCheckBox, QRadioButton {{ spacing: 8px; }}
QCheckBox::indicator, QRadioButton::indicator {{ width: 18px; height: 18px; }}
QCheckBox::indicator {{ border: 1.5px solid {p['border']}; border-radius: 5px; background: {p['input']}; }}
QCheckBox::indicator:checked {{ background: {acc}; border-color: {acc}; image: none; }}
QRadioButton::indicator {{ border: 1.5px solid {p['border']}; border-radius: 9px; background: {p['input']}; }}
QRadioButton::indicator:checked {{ background: {acc}; border: 4px solid {p['input']}; outline: 1px solid {acc}; }}

QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QTabWidget > QStackedWidget > QWidget {{ background: transparent; }}
QTextBrowser#paper {{ background: #FFFFFF; color: #111111; border: 1px solid {p['border']}; border-radius: 12px; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {p['border']}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {acc}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QTextBrowser {{ background: {p['surface2']}; border: 1px solid {p['border']}; border-radius: 12px; }}
QStatusBar {{ background: {p['surface']}; border-top: 1px solid {p['border']}; color: {p['muted']}; }}
QDialog {{ background: {p['bg']}; }}
"""
