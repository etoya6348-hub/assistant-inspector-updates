# -*- coding: utf-8 -*-
"""Assistant Inspector — fuqarolardan tushuntirish xati olish va so‘roq
bayonnomasini ovozdan avtomatik shakllantirish dasturi."""
import sys
import traceback
from pathlib import Path

LOG = Path(__file__).resolve().parent / "error_log.txt"


def _excepthook(etype, value, tb):
    text = "".join(traceback.format_exception(etype, value, tb))
    try:
        LOG.write_text(text, encoding="utf-8")
    except Exception:
        pass
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
        if QApplication.instance():
            QMessageBox.critical(None, "Assistant Inspector — xato", text[-2000:])
    except Exception:
        pass


sys.excepthook = _excepthook


def main():
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication

    from app.config import APP_NAME, base_dir
    from app.main_window import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    icon = base_dir() / "assets" / "icon.ico"
    if icon.exists():
        app.setWindowIcon(QIcon(str(icon)))
    w = MainWindow()
    if not w.startup_checks():
        sys.exit(0)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        _excepthook(*sys.exc_info())
        raise
