# -*- coding: utf-8 -*-
"""Oflayn (internetsiz) ishlash uchun nutqni aniqlash modellarini yuklab olish.

Bir marta internet bor kompyuterda ishga tushiriladi. Modellar dastur
yonidagi  models\\  papkasiga saqlanadi; shundan keyin dastur internetsiz ishlaydi.
models\\ papkasini boshqa kompyuterga (flesh orqali) ko‘chirish ham mumkin.
"""
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODELS = ROOT / "models"
MODELS.mkdir(exist_ok=True)


def pip(*args):
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", *args])


def rubaistt():
    """O‘zbek tiliga maxsus o‘rgatilgan Whisper-medium (islomov/rubaistt_v2_medium, Apache-2.0)
    -> CTranslate2 formatiga o‘tkaziladi (faster-whisper uchun)."""
    out = MODELS / "rubaistt_v2_medium_ct2"
    if (out / "model.bin").exists():
        print("✔ rubaistt_v2_medium allaqachon mavjud.")
        return
    print("→ Konvertatsiya uchun vaqtinchalik paketlar o‘rnatilmoqda (torch CPU, transformers)…")
    pip("torch", "--index-url", "https://download.pytorch.org/whl/cpu")
    pip("transformers", "ctranslate2", "huggingface_hub")
    from ctranslate2.converters import TransformersConverter
    from transformers import WhisperFeatureExtractor, WhisperTokenizerFast
    repo = "islomov/rubaistt_v2_medium"
    print(f"→ {repo} yuklab olinmoqda va o‘tkazilmoqda (≈1.5 GB)…")
    TransformersConverter(repo).convert(str(out), quantization="float16", force=True)
    WhisperTokenizerFast.from_pretrained(repo).save_pretrained(str(out))
    WhisperFeatureExtractor.from_pretrained(repo).save_pretrained(str(out))
    print(f"✔ Tayyor: {out}")


def whisper(name):
    from huggingface_hub import snapshot_download
    repo = {"large-v3": "Systran/faster-whisper-large-v3",
            "large-v3-turbo": "mobiuslabsgmbh/faster-whisper-large-v3-turbo",
            "medium": "Systran/faster-whisper-medium"}[name]
    out = MODELS / name
    print(f"→ {repo} yuklab olinmoqda…")
    snapshot_download(repo, local_dir=str(out))
    print(f"✔ Tayyor: {out}")


def vosk():
    name = "vosk-model-small-uz-0.22"
    out = MODELS / name
    if out.exists():
        print("✔ Vosk modeli allaqachon mavjud.")
        return
    url = f"https://alphacephei.com/vosk/models/{name}.zip"
    zpath = MODELS / f"{name}.zip"
    print(f"→ {url} yuklab olinmoqda (≈50 MB)…")
    urllib.request.urlretrieve(url, zpath)
    with zipfile.ZipFile(zpath) as z:
        z.extractall(MODELS)
    zpath.unlink(missing_ok=True)
    print(f"✔ Tayyor: {out}")


MENU = [
    ("O‘zbekcha Whisper — rubaistt_v2_medium (TAVSIYA: eng yaxshi o‘zbekcha sifat, ≈1.5 GB)", rubaistt),
    ("Whisper large-v3 (ko‘p tilli, ≈3 GB, kuchli kompyuter uchun)", lambda: whisper("large-v3")),
    ("Vosk o‘zbekcha (yengil, ≈50 MB, kuchsiz kompyuter uchun)", vosk),
]

if __name__ == "__main__":
    print("=" * 64)
    print(" Assistant Inspector — oflayn modellarni yuklab olish")
    print("=" * 64)
    for i, (title, _) in enumerate(MENU, 1):
        print(f" {i}. {title}")
    print(" A. Hammasi (1 va 3)")
    choice = (sys.argv[1] if len(sys.argv) > 1 else input("\nTanlang [1]: ")).strip().upper() or "1"
    todo = [MENU[0][1], MENU[2][1]] if choice == "A" else [MENU[int(c) - 1][1] for c in choice if c.isdigit()]
    for fn in todo:
        try:
            fn()
        except Exception as e:  # noqa
            print(f"✖ Xato: {e}")
    print("\nModellar papkasi:", MODELS)
    if sys.stdin and sys.stdin.isatty():
        input("Yopish uchun Enter bosing…")
