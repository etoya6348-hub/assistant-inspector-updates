# -*- coding: utf-8 -*-
"""Obuna (litsenziya), masofadan boshqarish siyosati va avtomatik yangilanish.

Ishonch asosi — Ed25519 raqamli imzo:
  * Admin o‘z kompyuterida `admin_tool.py` orqali kalit juftini yaratadi.
    Yopiq kalit FAQAT adminda qoladi, ochiq kalit `app/public_key.txt` ga yoziladi.
  * Litsenziya kalitlari, yangilanish manifesti va bloklangan qurilmalar ro‘yxati
    yopiq kalit bilan imzolanadi. Dastur ularni ochiq kalit bilan tekshiradi —
    imzosiz yoki soxta faylni qabul qilmaydi (xakerlar o‘z "yangilanish"ini
    yoki "litsenziya"sini kirita olmaydi).
"""
import base64
import datetime as dt
import hashlib
import io
import json
import shutil
import zipfile
from pathlib import Path

from .config import APP_VERSION, base_dir

PUBKEY_FILE = Path(__file__).resolve().parent / "public_key.txt"


def _pubkey():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        raw = base64.b64decode(PUBKEY_FILE.read_text().strip())
        return Ed25519PublicKey.from_public_bytes(raw)
    except Exception:
        return None


def is_configured() -> bool:
    return _pubkey() is not None


def verify(data: bytes, sig_b64: str) -> bool:
    pk = _pubkey()
    if pk is None:
        return False
    try:
        pk.verify(base64.b64decode(sig_b64), data)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ #
#                              Litsenziya                             #
# ------------------------------------------------------------------ #
def check_license(key: str, device: str):
    """Qaytaradi: (ok, matn). Kalit ko‘rinishi: <payload_b64>.<imzo_b64>"""
    key = (key or "").strip()
    if not key:
        return False, "Litsenziya kaliti kiritilmagan."
    try:
        payload_b64, sig = key.split(".")
        payload = base64.urlsafe_b64decode(payload_b64 + "==")
    except Exception:
        return False, "Kalit formati noto‘g‘ri."
    if not verify(payload, base64.b64encode(base64.urlsafe_b64decode(sig + "==")).decode()):
        return False, "Kalit imzosi haqiqiy emas."
    info = json.loads(payload)
    if info.get("device") not in (device, "*"):
        return False, "Kalit boshqa kompyuter uchun berilgan."
    exp = dt.date.fromisoformat(info["expires"])
    if exp < dt.date.today():
        return False, f"Obuna muddati tugagan ({exp:%d.%m.%Y})."
    plan = {"monthly": "oylik", "yearly": "yillik"}.get(info.get("plan"), info.get("plan", ""))
    return True, f"Obuna faol: {plan}, {exp:%d.%m.%Y} gacha. Egasi: {info.get('name', '')}"


# ------------------------------------------------------------------ #
#                    Manifest (yangilanish + siyosat)                 #
# ------------------------------------------------------------------ #
def _ver(v):
    return tuple(int(x) for x in str(v).split(".") if x.isdigit())


def fetch_manifest(base_url: str, timeout=8):
    """base_url ichida manifest.json va manifest.sig bo‘lishi kerak."""
    import requests
    base_url = base_url.rstrip("/")
    data = requests.get(base_url + "/manifest.json", timeout=timeout).content
    sig = requests.get(base_url + "/manifest.sig", timeout=timeout).text.strip()
    if not verify(data, sig):
        raise ValueError("Manifest imzosi tekshiruvdan o‘tmadi (soxta bo‘lishi mumkin).")
    return json.loads(data.decode("utf-8"))


def update_available(manifest):
    return _ver(manifest.get("version", "0")) > _ver(APP_VERSION)


def install_update(manifest, progress=None):
    """Arxivni yuklab, SHA-256 ni tekshirib, dastur fayllarini yangilaydi.
    .venv, models, Natija papkalari va foydalanuvchi maʼlumotlariga tegilmaydi."""
    import requests
    r = requests.get(manifest["download_url"], timeout=120)
    r.raise_for_status()
    data = r.content
    if hashlib.sha256(data).hexdigest().lower() != manifest.get("sha256", "").lower():
        raise ValueError("Yuklangan fayl butunligi tekshiruvdan o‘tmadi (SHA-256).")
    root = base_dir()
    keep = {".venv", "models", "Natija", "andozalar", "admin_keys", "publish"}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        prefix = ""
        if names and all(n.startswith(names[0].split("/")[0] + "/") for n in names):
            prefix = names[0].split("/")[0] + "/"
        backup = root / ".backup"
        shutil.rmtree(backup, ignore_errors=True)
        for n in names:
            rel = n[len(prefix):]
            if not rel or rel.split("/")[0] in keep or ".." in rel:
                continue
            dst = root / rel
            if dst.exists():
                (backup / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, backup / rel)
            dst.parent.mkdir(parents=True, exist_ok=True)
            with z.open(n) as src, open(dst, "wb") as out:
                out.write(src.read())
    return manifest.get("version")
