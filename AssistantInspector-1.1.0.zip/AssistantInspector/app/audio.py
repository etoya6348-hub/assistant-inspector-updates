# -*- coding: utf-8 -*-
"""Mikrofondan ovoz yozish va audio fayllarni o‘qish."""
import threading
import time
import wave

import numpy as np

SR = 16000


def list_input_devices():
    """Faqat asosiy (MME) tizimidagi mikrofonlar — takrorlanishlarsiz."""
    try:
        import sounddevice as sd
        out, seen = [], set()
        for i, d in enumerate(sd.query_devices()):
            if d.get("max_input_channels", 0) > 0 and d.get("hostapi", 0) == 0:
                if d["name"] not in seen:
                    seen.add(d["name"])
                    out.append((i, d["name"]))
        return out
    except Exception:
        return []


def _resample(a, sr_from, sr_to=SR):
    if sr_from == sr_to or len(a) == 0:
        return a.astype(np.float32)
    n = int(len(a) * sr_to / sr_from)
    return np.interp(np.linspace(0, len(a), n, endpoint=False),
                     np.arange(len(a)), a).astype(np.float32)


class Recorder:
    """16 kHz mono yozuv. level -> 0..1 (indikator uchun)."""

    def __init__(self, device=None):
        self.device = device
        self._chunks = []
        self._stream = None
        self._lock = threading.Lock()
        self.level = 0.0
        self.started_at = None
        self.paused = False
        self.rate = SR

    def _cb(self, indata, frames, t, status):
        if self.paused:
            self.level = 0.0
            return
        data = indata[:, 0].copy()
        with self._lock:
            self._chunks.append(data)
        rms = float(np.sqrt(np.mean(np.square(data.astype(np.float32))) + 1e-12))
        self.level = min(1.0, rms * 6)

    def start(self):
        import sounddevice as sd
        self._chunks = []
        devices = [self.device] if self.device is None else [self.device, None]
        last_err = None
        for dev in devices:
            try:
                info = sd.query_devices(dev, "input")
                rates = [SR, int(info.get("default_samplerate") or 44100), 48000, 44100]
            except Exception:
                rates = [SR, 48000, 44100]
            for rate in dict.fromkeys(rates):
                try:
                    stream = sd.InputStream(samplerate=rate, channels=1, dtype="float32", device=dev,
                                            callback=self._cb, blocksize=int(rate / 10))
                    stream.start()
                    self._stream, self.rate = stream, rate
                    break
                except Exception as e:  # noqa
                    last_err = e
            if self._stream is not None:
                break
        if self._stream is None:
            raise last_err or RuntimeError("Mikrofon topilmadi")
        self.started_at = time.time()
        self.paused = False

    def stop(self):
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            finally:
                self._stream = None
        self.level = 0.0
        with self._lock:
            if not self._chunks:
                return np.zeros(0, dtype=np.float32)
            return _resample(np.concatenate(self._chunks), self.rate)

    @property
    def active(self):
        return self._stream is not None


def save_wav(path, audio: np.ndarray, sr=SR):
    pcm = np.clip(audio, -1.0, 1.0)
    pcm = (pcm * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def load_audio(path) -> np.ndarray:
    """Istalgan formatdagi audio (wav, mp3, m4a, ogg, amr, ...) -> 16 kHz mono float32."""
    path = str(path)
    try:
        import av  # faster-whisper bilan birga o‘rnatiladi
        container = av.open(path)
        resampler = av.audio.resampler.AudioResampler(format="s16", layout="mono", rate=SR)
        parts = []
        for frame in container.decode(audio=0):
            frame.pts = None
            for f in resampler.resample(frame):
                parts.append(f.to_ndarray().reshape(-1))
        for f in resampler.resample(None):
            parts.append(f.to_ndarray().reshape(-1))
        container.close()
        if parts:
            return np.concatenate(parts).astype(np.float32) / 32768.0
        return np.zeros(0, dtype=np.float32)
    except ImportError:
        pass
    with wave.open(path, "rb") as w:
        sr, ch, sw = w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(w.getnframes())
    dtype = {1: np.int8, 2: np.int16, 4: np.int32}[sw]
    a = np.frombuffer(raw, dtype=dtype).astype(np.float32) / float(np.iinfo(dtype).max)
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    if sr != SR:
        n = int(len(a) * SR / sr)
        a = np.interp(np.linspace(0, len(a), n, endpoint=False), np.arange(len(a)), a).astype(np.float32)
    return a


def split_on_silence(audio: np.ndarray, max_sec=45, sr=SR):
    """Uzun audioni sukut joylaridan max_sec dan oshmaydigan bo‘laklarga ajratadi."""
    out, pos, n = [], 0, len(audio)
    max_len = int(max_sec * sr)
    win = int(0.2 * sr)
    while pos < n:
        end = min(n, pos + max_len)
        if end < n:
            search_from = pos + int(max_len * 0.6)
            seg = audio[search_from:end]
            if len(seg) > win:
                k = len(seg) // win
                energy = np.square(seg[:k * win]).reshape(k, win).mean(axis=1)
                end = search_from + int(np.argmin(energy)) * win + win // 2
        out.append(audio[pos:end])
        pos = end
    return out
