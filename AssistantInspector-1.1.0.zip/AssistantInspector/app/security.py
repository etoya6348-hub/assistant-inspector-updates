# -*- coding: utf-8 -*-
"""Xavfsizlik: shaxsga doir maʼlumotlarni shifrlash, parollar, qurilma ID, audit jurnali.

* Qoralama (draft) va maxfiy sozlamalar Windows DPAPI orqali shifrlanadi —
  faqat shu kompyuterdagi shu Windows foydalanuvchisi o‘qiy oladi. Fayl boshqa
  kompyuterga ko‘chirilsa ham ochilmaydi.
* Parollar ochiq saqlanmaydi: PBKDF2-SHA256 (200 000 iteratsiya) xeshi saqlanadi.
* Audit jurnali faqat hodisa turini yozadi (shaxs maʼlumotlarisiz).
"""
import base64
import datetime as dt
import hashlib
import hmac
import json
import os
import platform
import sys
import uuid

from .config import data_dir

_IS_WIN = sys.platform.startswith("win")


# ------------------------------------------------------------------ #
#                       Windows DPAPI shifrlash                       #
# ------------------------------------------------------------------ #
if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    _crypt32 = ctypes.windll.crypt32
    _kernel32 = ctypes.windll.kernel32
    _ENTROPY = b"AssistantInspector-v1"

    def _blob(data: bytes):
        buf = ctypes.create_string_buffer(data, len(data))
        return _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    def _protect(data: bytes) -> bytes:
        src, _b1 = _blob(data)
        ent, _b2 = _blob(_ENTROPY)
        out = _BLOB()
        if not _crypt32.CryptProtectData(ctypes.byref(src), None, ctypes.byref(ent), None, None,
                                         0x01, ctypes.byref(out)):
            raise OSError("CryptProtectData failed")
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(out.pbData)

    def _unprotect(data: bytes) -> bytes:
        src, _b1 = _blob(data)
        ent, _b2 = _blob(_ENTROPY)
        out = _BLOB()
        if not _crypt32.CryptUnprotectData(ctypes.byref(src), None, ctypes.byref(ent), None, None,
                                           0x01, ctypes.byref(out)):
            raise OSError("CryptUnprotectData failed")
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(out.pbData)
else:  # Windows bo‘lmagan tizimlar (sinov uchun) — oddiy kodlash
    def _protect(data: bytes) -> bytes:
        return data

    def _unprotect(data: bytes) -> bytes:
        return data


def encrypt_text(text: str) -> str:
    if not text:
        return ""
    return "dpapi:" + base64.b64encode(_protect(text.encode("utf-8"))).decode("ascii")


def decrypt_text(token: str) -> str:
    if not token:
        return ""
    if token.startswith("dpapi:"):
        try:
            return _unprotect(base64.b64decode(token[6:])).decode("utf-8")
        except Exception:
            return ""
    return token


def save_secure_json(path, obj):
    raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    payload = b"AIENC1" + _protect(raw)
    tmp = str(path) + ".tmp"
    with open(tmp, "wb") as f:
        f.write(payload)
    os.replace(tmp, path)


def load_secure_json(path):
    with open(path, "rb") as f:
        data = f.read()
    if data.startswith(b"AIENC1"):
        data = _unprotect(data[6:])
    return json.loads(data.decode("utf-8"))


def wipe_file(path):
    """Faylni o‘chirishdan oldin ustidan nol yozadi."""
    try:
        n = os.path.getsize(path)
        with open(path, "r+b") as f:
            f.write(b"\0" * n)
            f.flush()
            os.fsync(f.fileno())
        os.remove(path)
    except Exception:
        try:
            os.remove(path)
        except Exception:
            pass


# ------------------------------------------------------------------ #
#                               Parollar                              #
# ------------------------------------------------------------------ #
def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    it = 200_000
    h = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, it)
    return f"pbkdf2${it}${base64.b64encode(salt).decode()}${base64.b64encode(h).decode()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        _, it, salt, h = stored.split("$")
        calc = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), base64.b64decode(salt), int(it))
        return hmac.compare_digest(calc, base64.b64decode(h))
    except Exception:
        return False


# ------------------------------------------------------------------ #
#                              Qurilma ID                             #
# ------------------------------------------------------------------ #
def device_id() -> str:
    guid = ""
    if _IS_WIN:
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                               0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
            guid = winreg.QueryValueEx(k, "MachineGuid")[0]
        except Exception:
            guid = ""
    if not guid:
        guid = f"{uuid.getnode():x}-{platform.node()}"
    h = hashlib.sha256(("AI|" + guid).encode()).hexdigest().upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


# ------------------------------------------------------------------ #
#                             Audit jurnali                           #
# ------------------------------------------------------------------ #
def audit(event: str):
    try:
        with open(data_dir() / "audit.log", "a", encoding="utf-8") as f:
            f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S}  {event}\n")
    except Exception:
        pass


def read_audit(limit=300):
    try:
        lines = (data_dir() / "audit.log").read_text(encoding="utf-8").splitlines()
        return "\n".join(lines[-limit:])
    except Exception:
        return ""
