# -*- coding: utf-8 -*-
"""O‘zbek kirill <-> lotin transliteratsiyasi (1995-yilgi rasmiy qoidalar asosida)."""
import re

OKINA = "ʻ"      # ʻ  (oʻ, gʻ)
TUTUQ = "ʼ"      # ʼ  (tutuq belgisi)

_VOWELS_CYR = set("аеёиоуэюяўАЕЁИОУЭЮЯЎ")

_C2L = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "ё": "yo", "ж": "j",
    "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n",
    "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f",
    "х": "x", "ч": "ch", "ш": "sh", "щ": "sh", "ъ": TUTUQ, "ы": "i", "ь": "",
    "э": "e", "ю": "yu", "я": "ya", "ў": "o" + OKINA, "қ": "q",
    "ғ": "g" + OKINA, "ҳ": "h",
}

# Rasmiy imlosi farq qiladigan so‘zlar
_EXC_C2L = {
    "октябрь": "oktabr", "сентябрь": "sentabr", "январь": "yanvar",
    "февраль": "fevral", "апрель": "aprel", "июнь": "iyun", "июль": "iyul",
    "ноябрь": "noyabr", "декабрь": "dekabr", "август": "avgust", "март": "mart",
    "май": "may", "октябр": "oktabr", "сентябр": "sentabr", "декабр": "dekabr",
    "ноябр": "noyabr", "феврал": "fevral", "январ": "yanvar",
}

_CYR_WORD = re.compile(r"[А-Яа-яЁёЎўҚқҒғҲҳ]+")


def _split_abbr(word):
    """'ЖПКнинг' -> ('ЖПК', 'нинг'): qisqartma + qo‘shimcha."""
    n = 0
    while n < len(word) and word[n].isupper():
        n += 1
    if n >= 2 and n < len(word) and word[n:].islower():
        return word[:n], word[n:]
    return None


def _word_c2l(word: str) -> str:
    sp = _split_abbr(word)
    if sp:
        return _word_c2l(sp[0]) + _word_c2l(sp[1])
    low = word.lower()
    if low in _EXC_C2L:
        res = _EXC_C2L[low]
    else:
        out = []
        for i, ch in enumerate(low):
            prev = low[i - 1] if i > 0 else ""
            if ch == "е":
                out.append("ye" if (i == 0 or prev in "аеёиоуэюяўъь") else "e")
            elif ch == "ц":
                out.append("ts" if (i > 0 and prev in "аеёиоуэюяў") else "s")
            else:
                out.append(_C2L.get(ch, ch))
        res = "".join(out)
    # Harf kattaligini tiklash
    if len(word) > 1 and word.isupper():
        return res.upper()
    if word[:1].isupper():
        return res[:1].upper() + res[1:]
    return res


def to_latin(text: str) -> str:
    if not text:
        return text
    return _CYR_WORD.sub(lambda m: _word_c2l(m.group(0)), text)


# ---------------- Lotin -> Kirill ----------------
_APOS = "'`‘’ʻʼ"
_L2C_MULTI = [
    ("o" + OKINA, "ў"), ("g" + OKINA, "ғ"), ("sh", "ш"), ("ch", "ч"),
    ("yo", "ё"), ("yu", "ю"), ("ya", "я"), ("ye", "е"),
]
_L2C = {
    "a": "а", "b": "б", "d": "д", "e": "е", "f": "ф", "g": "г", "h": "ҳ",
    "i": "и", "j": "ж", "k": "к", "l": "л", "m": "м", "n": "н", "o": "о",
    "p": "п", "q": "қ", "r": "р", "s": "с", "t": "т", "u": "у", "v": "в",
    "x": "х", "y": "й", "z": "з", "c": "с", "w": "в", TUTUQ: "ъ",
}
_LAT_WORD = re.compile(r"[A-Za-z" + OKINA + TUTUQ + r"]+")
_EXC_L2C = {"oktabr": "октябрь", "sentabr": "сентябрь", "yanvar": "январь",
            "fevral": "февраль", "aprel": "апрель", "iyun": "июнь",
            "iyul": "июль", "noyabr": "ноябрь", "dekabr": "декабрь"}


def normalize_latin(text: str) -> str:
    """Apostroflarni yagona ko‘rinishga keltiradi: oʻ gʻ va ʼ."""
    if not text:
        return text
    text = re.sub(r"([OoGg])[" + re.escape(_APOS) + r"]", lambda m: m.group(1) + OKINA, text)
    text = re.sub(r"(?<=[A-Za-z])[" + re.escape("'`’ʼ") + r"](?=[A-Za-z])", TUTUQ, text)
    return text


def _word_l2c(word: str) -> str:
    sp = _split_abbr(word)
    if sp and len(sp[0]) <= 5:
        return _word_l2c(sp[0]) + _word_l2c(sp[1])
    low = word.lower()
    if low in _EXC_L2C:
        res = _EXC_L2C[low]
    else:
        out, i = [], 0
        while i < len(low):
            # "yoʻ" -> "йў" (masalan yoʻl -> йўл)
            if low.startswith("yo" + OKINA, i):
                out.append("й"); i += 1; continue
            done = False
            for lat, cyr in _L2C_MULTI:
                if low.startswith(lat, i):
                    out.append(cyr); i += len(lat); done = True
                    break
            if done:
                continue
            ch = low[i]
            if ch == "e":
                prev = low[i - 1] if i > 0 else ""
                out.append("э" if (i == 0 or prev in "aeiou" + OKINA + TUTUQ) else "е")
            else:
                out.append(_L2C.get(ch, ch))
            i += 1
        res = "".join(out)
    if len(word) > 1 and word.replace(OKINA, "").replace(TUTUQ, "").isupper():
        return res.upper()
    if word[:1].isupper():
        return res[:1].upper() + res[1:]
    return res


def to_cyrillic(text: str) -> str:
    if not text:
        return text
    text = normalize_latin(text)
    return _LAT_WORD.sub(lambda m: _word_l2c(m.group(0)), text)


def convert(text: str, script: str) -> str:
    """script: 'latn' yoki 'cyrl'. Matn qaysi alifboda bo‘lishidan qat’i nazar
    kerakli alifboga o‘tkaziladi."""
    if script == "cyrl":
        return to_cyrillic(text)
    return normalize_latin(to_latin(text))
