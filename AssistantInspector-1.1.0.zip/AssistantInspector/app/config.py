# -*- coding: utf-8 -*-
import copy
import json
import os
import sys
from pathlib import Path

from .templates_data import DEFAULT_TEMPLATES

APP_NAME = "Assistant Inspector"
APP_VERSION = "1.1.0"


def base_dir() -> Path:
    """Dastur joylashgan papka (exe yoki main.py yonida)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def data_dir() -> Path:
    root = os.environ.get("APPDATA") or str(Path.home() / ".config")
    d = Path(root) / "AssistantInspector"
    d.mkdir(parents=True, exist_ok=True)
    return d


def models_dir() -> Path:
    d = base_dir() / "models"
    d.mkdir(parents=True, exist_ok=True)
    return d


def default_output_dir() -> str:
    return str(base_dir() / "Natija")


RANKS = ["лейтенант", "катта лейтенант", "капитан", "майор", "подполковник"]
UNITS = [("tb", "Тергов бўлинмаси", "тергов бўлинмаси"),
         ("prof", "Профилактика", "профилактика бўлинмаси"),
         ("jq", "Жиноят қидирув", "жиноят қидирув бўлинмаси"),
         ("custom", "Эркин киритиш", "")]


PRESET_COLORS = [
    {"key": "indigo", "color": "#6366F1"},
    {"key": "emerald", "color": "#10B981"},
    {"key": "ocean", "color": "#0EA5E9"},
    {"key": "rose", "color": "#F43F5E"},
    {"key": "amber", "color": "#F59E0B"},
]

DEFAULT_SETTINGS = {
    "ui_lang": "uz_latn",          # uz_latn | uz_cyrl | ru | en
    "doc_script": "latn",          # latn | cyrl
    "dark": False,
    "theme_index": 0,
    "theme_colors": [c["color"] for c in PRESET_COLORS],
    "stt_mode": "auto",            # auto | offline | online
    "offline_engine": "whisper",   # whisper | vosk
    "whisper_model": "rubaistt_v2_medium_ct2",
    "whisper_device": "auto",      # auto | cpu | cuda
    "vosk_model": "vosk-model-small-uz-0.22",
    "online_engine": "google",     # google | openai
    "openai_key": "",
    "openai_model": "gpt-4o-transcribe",
    "mic_device": None,
    "output_dir": default_output_dir(),
    "open_after_save": True,
    "investigator": {
        "org_base": "Янги Наманган тумани ички ишлар бўлими",
        "unit": "tb",
        "unit_custom": "",
        "position": "Янги Наманган тумани ИИБ ҳузуридаги ТБ терговчиси",
        "rank": "лейтенант",
        "fio": "",
        "place": "Янги Наманган тумани",
    },
    "security": {
        "admin_hash": "",
        "pin_hash": "",
        "autolock_min": 0,
        "offline_only": False,
        "settings_locked": False,
        "update_url": "",
        "auto_update": True,
        "require_license": False,
        "license_key": "",
    },
    "addressee": {
        "position": "Янги Наманган тумани ИИБ бошлиғи подполковник",
        "fio": "",
    },
}


def _merge(defaults, loaded):
    out = copy.deepcopy(defaults)
    for k, v in (loaded or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


class Settings:
    def __init__(self):
        self.path = data_dir() / "settings.json"
        loaded = {}
        if self.path.exists():
            try:
                loaded = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                loaded = {}
        self.data = _merge(DEFAULT_SETTINGS, loaded)
        # Eski versiyadan o‘tish
        old_docs = str(Path.home() / "Documents" / "Assistant Inspector")
        if self.data.get("output_dir") in (old_docs, "", None):
            self.data["output_dir"] = default_output_dir()
        self.data["investigator"].pop("org", None)
        if self.data["investigator"].get("rank") not in RANKS:
            self.data["investigator"]["rank"] = RANKS[0]
        self.data.pop("openai_key_plain", None)

    def __getitem__(self, k):
        return self.data[k]

    def __setitem__(self, k, v):
        self.data[k] = v
        self.save()

    def get(self, k, default=None):
        return self.data.get(k, default)

    def save(self):
        try:
            self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass


def load_templates():
    """templates.json mavjud bo‘lmasa yaratadi; foydalanuvchi tahrirlagan matnlarni yuklaydi."""
    path = data_dir() / "templates.json"
    if not path.exists():
        path.write_text(json.dumps(DEFAULT_TEMPLATES, ensure_ascii=False, indent=2), encoding="utf-8")
        return copy.deepcopy(DEFAULT_TEMPLATES)
    try:
        return _merge(DEFAULT_TEMPLATES, json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return copy.deepcopy(DEFAULT_TEMPLATES)


def templates_path() -> Path:
    return data_dir() / "templates.json"
